# ZPhone for Z-City (fix73 DLL)

**fix73 (DLL build `fix73-phone-line`, addon fix73) — phone calls hear the real surroundings:**
- **the line goes from phone to phone, not from player to player.** Every phone of a connected call
  (phone ↔ phone and the 911 caller; the operator talks over a headset) is a microphone and a
  speaker *where it really is*: in the hand (at the eyes), **on the floor / on a table** (put down
  with MMB, dropped, fallen off a body) or **in a pocket** (another weapon in the hand: muffled).
  Before fix73 the other side heard only the holder, and only while the phone was in his hand.
- **voices** (server, no DLL needed): everybody who talks near a phone of the call is heard at the
  other phone — the same microphone curve as the clip microphone (≤ 40 units full, then 40/distance,
  nothing beyond 900, a wall ×0.42, a pocket ×0.6). The other phone's speaker is heard by its holder
  (phone volume, at least 0.3), quietly by the carrier with the phone in his pocket, and by everybody
  within `PhoneSpeakerDist` (280) of the phone by distance (a wall ×0.35). Two people standing within
  360 units of each other keep their own 3D voices. Gag (ULX / SAM / FAdmin), Z-City brain damage
  and Gordon stay silent, as before.
- **game sounds** (needs this DLL on the listening PC): shots, steps, doors, screams, cars, NPCs…
  around the other phone. The server sends where that phone is (10×/s) and every sound loud enough
  there (≤ 40 messages/s per listener, nothing while nobody is on a call); the DLL decodes the files
  (the same bank as the clip ear) and plays them through **its own Windows sound output** — Source's
  fall-off at the other phone, walls muffle, far sounds lose their highs, a pocket muffles, the
  phone's speaker volume, a phone-band filter, a soft limiter. It follows the game's `volume` and
  "mute when not in focus". A player within 600 units of the other phone hears those sounds himself,
  and sounds within 600 units of the listener (his own steps and shots) are not echoed back to him.
- `zhphone_line_ear` 1 (0 = no game sounds in calls), `zhphone_line_band` 0 full / **1 HD voice
  120–7000 Hz** / 2 old phone 300–3400 Hz, `zhphone_line_gain` (0–4), `zhphone_line_stats`.
- needs the fix73 addon on the **server** (it knows the build `fix73-phone-line`; an older addon
  would refuse this DLL). Clients without the DLL still get the voices.
- Not carried over the line: sounds that only one client plays (client-side effects, BASS music /
  radio / `sound.PlayFile`), map ambients; other players' voice chat is not band-filtered (GMod plays it).


**fix70 (DLL build `fix70-cpu-fallback`) — old and integrated GPUs:**
- **no hardware H.264 encoder** (GeForce GT 2xx–6xx / GTX 400–500 Fermi, old Radeon HD, old Intel
  graphics, drivers without NVENC/AMF/Media Foundation): the clip is no longer lost or silent.
  While filming the frame is read back by the encoder thread and written as **MJPEG** (CPU, FFmpeg,
  x86 assembly, 2–4 threads), with the same AAC sound (sound never depended on the GPU). After the
  stop the clip is **converted to a normal H.264 MP4** (Windows' own Media Foundation software
  encoder, `+faststart`, BT.709) — plays in Discord, browsers, phones. The phone shows
  "Processing video NN%". If the conversion fails (Windows N without the Media Feature Pack) the
  MJPEG clip is kept.
- `zhphone_encoder 4` = use this path even with a GPU encoder (to test it).
- **NVIDIA:** built against the NVENC API 11.1 (nv-codec-headers n11.1.5.3): works with drivers
  **471.41+** — also Kepler GTX 600/700 on their last 470/474 driver (fix69 needed 570+).
- D3D11 devices without video support (old GPUs/drivers) are opened without it.
- Media Foundation software H.264 is no longer tried **live** (too slow next to the game).
- needs the fix70 addon (it knows the build `fix70-cpu-fallback`).


**fix69 (DLL build `fix69-multigpu`) — any GPU, 64-bit and 32-bit Garry's Mod:**
- the video encoder is picked automatically, the first one that opens on your PC:
  **NVIDIA** NVENC (as before) → **AMD** AMF (Radeon, the same BGRA GPU frames as NVENC: same
  picture, same bitrate, FXAA, sound) → **Media Foundation** (Intel Quick Sync and every other
  DirectX 11 GPU; the frame is turned into NV12 on the GPU first) → Media Foundation software.
  `zhphone_encoder 0` auto (default), `1` NVENC first, `2` AMF first, `3` Media Foundation first.
  `zhphone_rec_stats` shows which one recorded the last clip (`Video encoder: h264_amf` ...).
- **32-bit build** `gmcl_zhphone_win32.dll` for the normal (non x86-64) branch of Garry's Mod, the
  same code and features; `install.bat` installs both, the game loads the one of its branch.
- needs the fix69 addon (it knows the build `fix69-multigpu`).


**fix67 (DLL build `fix66-export`):** Save in Photos writes a real **`.mp4`** into
`garrysmod/data/zhunter_saved/` again (the module copies the clip on its own thread; Lua itself
may only write `.dat`, so without this DLL the file is `*.mp4.dat` — rename it to `.mp4`).
Everything else is the same as fix64. Needs the fix67 addon.


A smartphone for the Garry's Mod gamemode **Z-City**: calls, 911, TeleChat, camera, photo/video,
gallery, settings, control centre, clock, music. Standalone addon: Z-City files are not modified.

**fix64 — smooth recording + FXAA:**
- **FXAA on phone videos** (FXAA 3.11, quality preset 39) — done on the GPU inside the encoder
  thread right before NVENC, on the full-resolution frame: no extra in-game FPS cost, no change of
  resolution / bitrate. `zhphone_fxaa 1` (default, sharp), `2` (stronger smoothing), `0` off.
  The live viewfinder and photos are not changed.
- **No freeze when recording starts:** the NVENC session (D3D11 device, encoder, textures, FXAA
  shaders) is prepared in the background while the camera is open; pressing record only switches
  it on. The textures are created one per frame instead of all at once.
- **Less stutter with many addons:** the stutter profiler is off by default (`zhphone_diag 0` —
  before fix64 it wrapped every hook/net/timer of every addon); the phone's hook wrappers no longer
  stack up again and again on top of other addons' wrappers.
- **Phone ear without hitches:** game sound files are read with `file.AsyncRead` (not on the game
  thread) and decoded by the DLL on its own low-priority thread; a sound whose file is still being
  read is placed at the moment it really started (no shift). Often used sounds are pre-loaded
  while the camera is open (`data/stts_phone_ear64.txt`).
- The "ZPhone - fix63 DLL compat" addon is **not needed any more — unsubscribe it** (with the
  fix64 addon it would mute the phone's ear).

**fix62:** phone videos record **real sound** — your microphone (while you talk in voice chat) and
the game's own audio — as AAC inside the MP4, in sync with the video, through the optional native
recorder (H.264 NVENC).

**fix63 — the phone's own ear:** the game sound of a clip is heard **where the phone is**, not at
your head (like the camera in *Content Warning*). Every sound the game starts is re-played by the
native module into the clip at the phone's position: Source's distance fall-off, walls muffle,
far sounds lose their highs, moving sources are followed, pitch and loops as in the game. Sounds
only the server plays (NPCs, doors, other players' steps and shots) are relayed by the server
(fix63 addon needed there). While the phone is at your head (< ~70 units) the clip uses "what you
hear" (with the other players' voice chat), beyond ~170 units only the phone's ear, crossfaded in
between. Not heard by the ear (only near you): other players' voice chat, BASS streams
(`sound.PlayFile` / `PlayURL`: radio, music, Glide engines), map ambients, sounds started before
recording; room DSP/echo is not re-created.

## Install

1. Update the phone addon (**fix73**) on the server / from the Workshop and **unsubscribe "ZPhone - fix63 DLL compat"**.
2. Close Garry's Mod.
3. Run **`install.bat`**. It finds Garry's Mod through Steam (registry, all library folders,
   common folders on every drive), backs up the old DLLs to `GarrysMod\zphone_backup_<date>\`
   and copies **only** the native part (nothing in `garrysmod\addons` is touched):

   | From this package | To |
   |---|---|
   | `garrysmod\lua\bin\gmcl_zhphone_win64.dll` | `GarrysMod\garrysmod\lua\bin\` |
   | `bin\win64\av*-zhphone32-*.dll` (3 files) | `GarrysMod\bin\win64\` |
   | `garrysmod\cfg\zhphone_native.cfg` | `GarrysMod\garrysmod\cfg\` |

   Not found? `install.bat "D:\SteamLibrary\steamapps\common\GarrysMod"` - or copy the
   `garrysmod` and `bin` folders into your `GarrysMod` folder by hand.
4. Start the game and run once in the console: `exec zhphone_native`. After a recording
   `zhphone_rec_stats` shows `Client fix73`, `Native module: fix73-phone-line` and the FXAA mode;
   during a call `zhphone_line_stats` shows the other phone, the output device and the sounds played.

**Server:** only the Workshop addons (no DLL). fix73: the voices of a call work for everybody with
the new addon; the game sounds of a call need this DLL on the listener's PC.

## Requirements for the native recorder

- Garry's Mod 64-bit (x86-64 branch) or 32-bit (default branch) — fix69 has both
- best: a GPU with a hardware H.264 encoder: NVIDIA GTX 600+ (NVENC, driver 471.41+), AMD
  Radeon HD 7000+ (AMF, a recent driver; otherwise through Media Foundation), Intel HD 2000+
  (Quick Sync through Media Foundation); default D3D9Ex renderer (no DXVK)
- fix70: any other DirectX 10/11 GPU: CPU path (MJPEG while filming, H.264 after the stop);
  needs Media Foundation for the H.264 step (Windows N: install the Media Feature Pack)
- FXAA: `d3dcompiler_47.dll` (part of Windows 10/11; without it the video is recorded without FXAA)
- Game sound: Windows 10 2004 (build 19041) or newer
- Microphone: Windows Settings → Privacy → Microphone → *Let desktop apps access your microphone*

## Console variables

| Variable | Default | Meaning |
|---|---|---|
| `zhphone_audio` | 1 | 0 = silent clips |
| `zhphone_audio_mic` | 1 | 0 off, 1 only while you talk in voice chat, 2 always |
| `zhphone_audio_game` | 1 | 0 off, 1 Garry's Mod only, 2 + whole-PC sound on older Windows |
| `zhphone_audio_ear` | 1 | fix63: 0 game heard at your head (fix62), 1 at the phone + "what you hear" while it is near you, 2 only at the phone |
| `zhphone_encoder` | 0 | fix69/70: 0 auto (NVENC, AMF, Media Foundation, then CPU), 1 NVENC first, 2 AMF first, 3 Media Foundation first, 4 CPU (MJPEG → H.264 after the stop) |
| `zhphone_fxaa` | 1 | fix64: FXAA on recorded videos — 0 off, 1 quality (sharp), 2 strong |
| `zhphone_diag` | 0 | fix64: 1 = load the stutter profiler on the next reconnect / map change (costs FPS, for measuring only) |
| `zhphone_audio_mic_gain` | 1 | microphone loudness (0–4) |
| `zhphone_audio_play` | 1 | sound when watching clips in the gallery |
| `zhphone_rec_stats` | — | recorder + clip sound state after a recording |
| `zhphone_line_ear` | 1 | fix73: game sounds around the other phone of a call (0 off) |
| `zhphone_line_band` | 1 | fix73: sound of a call — 0 full band, 1 HD voice 120–7000 Hz, 2 old phone 300–3400 Hz |
| `zhphone_line_gain` | 1 | fix73: loudness of those sounds (0–4) |
| `zhphone_line_stats` | — | fix73: the line during a call (other phone, output device, voices) |

## Uninstall the native part

Close the game, delete `garrysmod\lua\bin\gmcl_zhphone_win64.dll` and the three
`bin\win64\av*-zhphone32-*.dll`.

## Source and licenses

`native_source/` — DLL source (`src/`, FXAA in `src/gpu_fxaa.h`), FFmpeg SDK, build scripts and logs
(`build-info/`), the audio and phone-ear tests (`tests/audio/`, `tests/ear/`), third-party sources
and licenses (`native_source/third-party/`, incl. the NVIDIA FXAA 3.11 notice).

**Status (fix73):** both DLLs cross-built (0 warnings, `build-info/module-fix73-*.log`); the phone line
(`src/phone_line.h`) passes its Linux test with ASan/UBSan (`tests/line73/`: band filters, muffle, pitch,
loops/stop fade, late start, voice cap, limiter, NaN input; WASAPI player on a fake device: float /
int16 5.1 / 24-bit / mono, device lost → reopened, default device changed, watchdog, no device); the
Lua simulation passes (`tests/lua_ear/`: line client 27 checks, line server 42 checks, the fix63/fix64
clip-ear tests unchanged 70 checks). **Not tested in-game on Windows yet.**

**Status (fix64):** built offline (Windows x64 cross-build, 0 warnings, rebuilt byte for byte from
`native_source/`); the FXAA shaders compile (DXC, SM 6.0) and the FXAA algorithm was checked on test
images; the phone-ear and audio tests pass with ASan/UBSan (background decoding, placement of late sounds),
the Lua simulation of the phone ear passes (async file reading, 70 checks).
**Not tested in-game on Windows / on a GPU yet.**
