@echo off
setlocal EnableExtensions
title ZPhone native recorder (fix70) - installer
rem Copies ONLY the native recorder into Garry's Mod:
rem   garrysmod\lua\bin\gmcl_zhphone_win64.dll
rem   bin\win64\avcodec-zhphone32-62.dll, avformat-zhphone32-62.dll, avutil-zhphone32-60.dll
rem   garrysmod\cfg\zhphone_native.cfg
rem fix69: + the 32-bit build for the normal (non x86-64) Garry's Mod:
rem   garrysmod\lua\bin\gmcl_zhphone_win32.dll
rem   avcodec-zhphonex86-62.dll, avformat-zhphonex86-62.dll, avutil-zhphonex86-60.dll
rem     into GarrysMod\ (next to hl2.exe) and GarrysMod\bin\
rem Both are installed: Garry's Mod loads the one that matches the branch you play on.
rem The phone addon itself comes from the Workshop - nothing in garrysmod\addons is touched.
rem Usage: install.bat ["D:\SteamLibrary\steamapps\common\GarrysMod"]
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
for %%F in ("garrysmod\lua\bin\gmcl_zhphone_win64.dll" "garrysmod\lua\bin\gmcl_zhphone_win32.dll" "bin\win64\avcodec-zhphone32-62.dll" "bin\win64\avformat-zhphone32-62.dll" "bin\win64\avutil-zhphone32-60.dll" "bin\x86\avcodec-zhphonex86-62.dll" "bin\x86\avformat-zhphonex86-62.dll" "bin\x86\avutil-zhphonex86-60.dll" "garrysmod\cfg\zhphone_native.cfg") do (
  if not exist "%SRC%\%%~F" (
    echo [ERROR] "%%~F" is missing next to install.bat. Unpack the whole zip first, then run install.bat from that folder.
    goto :fail
  )
)

rem ---- 1. find Garry's Mod
set "GMOD="
if not "%~1"=="" call :tryGmod "%~1"
if defined GMOD goto :found
rem Steam registry (HKCU + HKLM 32/64), every library in libraryfolders.vdf, then common folders on every fixed drive
for /f "usebackq delims=" %%G in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$q=[char]34;$roots=@();foreach($k in 'HKCU:\Software\Valve\Steam','HKLM:\SOFTWARE\WOW6432Node\Valve\Steam','HKLM:\SOFTWARE\Valve\Steam'){try{$p=Get-ItemProperty -Path $k -ErrorAction Stop;if($p.SteamPath){$roots+=$p.SteamPath};if($p.InstallPath){$roots+=$p.InstallPath}}catch{}};$libs=@();foreach($s in $roots){$s=$s.Replace('/','\');$libs+=$s;$v=Join-Path $s 'steamapps\libraryfolders.vdf';if(Test-Path -LiteralPath $v){$re=('{0}path{0}\s+{0}([^{0}]+){0}' -f $q);foreach($m in [regex]::Matches([IO.File]::ReadAllText($v),$re)){$libs+=$m.Groups[1].Value.Replace('\\','\')}}};foreach($d in [IO.DriveInfo]::GetDrives()){if($d.DriveType -eq 'Fixed'){foreach($n in 'SteamLibrary','Steam','Program Files (x86)\Steam','Program Files\Steam','Games\Steam','Games\SteamLibrary'){$libs+=Join-Path $d.RootDirectory.FullName $n}}};$seen=@{};foreach($l in $libs){$k=$l.ToLower();if($seen[$k]){continue};$seen[$k]=1;$g=Join-Path $l 'steamapps\common\GarrysMod';if(Test-Path -LiteralPath (Join-Path $g 'garrysmod\gameinfo.txt')){$g;break}}" 2^>nul`) do if not defined GMOD set "GMOD=%%G"
if defined GMOD goto :found
echo Garry's Mod was not found automatically.
set "ASK="
set /p "ASK=Paste the GarrysMod folder (the one with garrysmod and bin inside): "
if defined ASK set "ASK=%ASK:"=%"
if defined ASK call :tryGmod "%ASK%"
if not defined GMOD (
  echo [ERROR] Not a Garry's Mod folder.
  goto :fail
)

:found
echo Garry's Mod: "%GMOD%"

rem ---- 2. the game must be closed (the DLL is locked while it runs)
tasklist /FI "IMAGENAME eq gmod.exe" 2>nul | find /i "gmod.exe" >nul && goto :running
tasklist /FI "IMAGENAME eq hl2.exe" 2>nul | find /i "hl2.exe" >nul && goto :running

if exist "%GMOD%\bin\win64\" (echo Branch: x86-64 ^(64-bit^) - gmcl_zhphone_win64.dll will be used) else (echo Branch: 32-bit - gmcl_zhphone_win32.dll will be used)

rem ---- 3. backup of the old DLLs only
set "STAMP="
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss" 2^>nul') do set "STAMP=%%T"
if not defined STAMP set "STAMP=%RANDOM%%RANDOM%"
set "BK=%GMOD%\zphone_backup_%STAMP%"
set "DIDBK="
for %%F in ("%GMOD%\garrysmod\lua\bin\gmcl_zhphone_win64.dll" "%GMOD%\garrysmod\lua\bin\gmcl_zhphone_win32.dll" "%GMOD%\bin\win64\avcodec-zhphone32-62.dll" "%GMOD%\bin\win64\avformat-zhphone32-62.dll" "%GMOD%\bin\win64\avutil-zhphone32-60.dll" "%GMOD%\garrysmod\cfg\zhphone_native.cfg") do (
  if exist %%F (
    mkdir "%BK%" 2>nul
    copy /Y %%F "%BK%\" >nul
    set "DIDBK=1"
  )
)
if defined DIDBK echo Backup of the old DLLs: "%BK%"

rem ---- 4. copy
echo Copying the native recorder...
if not exist "%GMOD%\garrysmod\lua\bin\" mkdir "%GMOD%\garrysmod\lua\bin"
copy /Y "%SRC%\garrysmod\lua\bin\gmcl_zhphone_win64.dll" "%GMOD%\garrysmod\lua\bin\" >nul || goto :copyfail
if not exist "%GMOD%\bin\win64\" mkdir "%GMOD%\bin\win64"
copy /Y "%SRC%\bin\win64\avcodec-zhphone32-62.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
copy /Y "%SRC%\bin\win64\avformat-zhphone32-62.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
copy /Y "%SRC%\bin\win64\avutil-zhphone32-60.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
rem fix69: the 32-bit module and its FFmpeg (next to hl2.exe + in bin, both are searched by the 32-bit game)
copy /Y "%SRC%\garrysmod\lua\bin\gmcl_zhphone_win32.dll" "%GMOD%\garrysmod\lua\bin\" >nul || goto :copyfail
for %%D in ("%GMOD%" "%GMOD%\bin") do (
  if not exist "%%~D\" mkdir "%%~D"
  copy /Y "%SRC%\bin\x86\avcodec-zhphonex86-62.dll" "%%~D\" >nul || goto :copyfail
  copy /Y "%SRC%\bin\x86\avformat-zhphonex86-62.dll" "%%~D\" >nul || goto :copyfail
  copy /Y "%SRC%\bin\x86\avutil-zhphonex86-60.dll" "%%~D\" >nul || goto :copyfail
)
if not exist "%GMOD%\garrysmod\cfg\" mkdir "%GMOD%\garrysmod\cfg"
copy /Y "%SRC%\garrysmod\cfg\zhphone_native.cfg" "%GMOD%\garrysmod\cfg\" >nul || goto :copyfail
rem files from a downloaded zip carry the "downloaded from the internet" mark: remove it
powershell -NoProfile -Command "Get-ChildItem -LiteralPath ($env:GMOD+'\garrysmod\lua\bin'),($env:GMOD+'\bin\win64'),($env:GMOD+'\bin'),$env:GMOD -Filter *zhphone* | Unblock-File" >nul 2>nul

echo.
echo Done. Installed:
echo   garrysmod\lua\bin\gmcl_zhphone_win64.dll
echo   bin\win64\avcodec-zhphone32-62.dll, avformat-zhphone32-62.dll, avutil-zhphone32-60.dll
echo   garrysmod\lua\bin\gmcl_zhphone_win32.dll + avcodec/avformat/avutil-zhphonex86 ^(32-bit^)
echo   garrysmod\cfg\zhphone_native.cfg
echo.
echo Update the phone addon from the Workshop. UNSUBSCRIBE "ZPhone - fix63 DLL compat" - it is not needed any more.
echo Start Garry's Mod and type ONCE in the console:  exec zhphone_native
echo Check ^(after a recording^):  zhphone_rec_stats   ^(shows "Client fix70", the DLL build, the video encoder and FXAA^)
echo.
pause
exit /b 0

:running
echo [ERROR] Garry's Mod ^(or another Source game^) is running. Close it completely and run install.bat again.
goto :fail
:copyfail
echo [ERROR] A file could not be copied ^(Garry's Mod still running? No write access - run install.bat as administrator^).
goto :fail
:fail
echo.
pause
exit /b 1

rem ---- helpers
:tryGmod
if "%~1"=="" exit /b 0
set "TRY=%~1"
if "%TRY:~-1%"=="\" set "TRY=%TRY:~0,-1%"
if exist "%TRY%\garrysmod\gameinfo.txt" (set "GMOD=%TRY%" & exit /b 0)
if exist "%TRY%\gameinfo.txt" if exist "%TRY%\..\garrysmod\" for %%P in ("%TRY%\..") do set "GMOD=%%~fP"
if exist "%TRY%\steamapps\common\GarrysMod\garrysmod\gameinfo.txt" set "GMOD=%TRY%\steamapps\common\GarrysMod"
exit /b 0
