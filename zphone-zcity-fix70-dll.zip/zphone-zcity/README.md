# ZPhone for Z-City (fix70 DLL)

**fix70 (DLL build `fix70-cpu-fallback`) — old and integrated GPUs:**
- **no hardware H.264 encoder** (GeForce GT 2xx–6xx / GTX 400–500 Fermi, old Radeon HD, old Intel
  graphics, drivers without NVENC/AMF/Media Foundation): the clip is no longer lost or silent.
  While filming the frame is read back by the encoder thread and written as **MJPEG** (CPU, FFmpeg,
  x86 assembly, 2–4 threads), with the same AAC sound (sound never depended on the GPU). After the
  stop the clip is **converted to a normal H.264 MP4** (Windows' own Media Foundation software
  encoder, `+faststart`, BT.709) — plays in Discord, browsers, phones. The phone shows
  "Processing video NN%". If the conversion fails (Windows N without the Media Feature Pack) the
  MJPEG clip is kept.
- `zhphone_encoder 4` = use this path even with a GPU encoder (to test it).
- **NVIDIA:** built against the NVENC API 11.1 (nv-codec-headers n11.1.5.3): works with drivers
  **471.41+** — also Kepler GTX 600/700 on their last 470/474 driver (fix69 needed 570+).
- D3D11 devices without video support (old GPUs/drivers) are opened without it.
- Media Foundation software H.264 is no longer tried **live** (too slow next to the game).
- needs the fix70 addon (it knows the build `fix70-cpu-fallback`).


**fix69 (DLL build `fix69-multigpu`) — any GPU, 64-bit and 32-bit Garry's Mod:**
- the video encoder is picked automatically, the first one that opens on your PC:
  **NVIDIA** NVENC (as before) → **AMD** AMF (Radeon, the same BGRA GPU frames as NVENC: same
  picture, same bitrate, FXAA, sound) → **Media Foundation** (Intel Quick Sync and every other
  DirectX 11 GPU; the frame is turned into NV12 on the GPU first) → Media Foundation software.
  `zhphone_encoder 0` auto (default), `1` NVENC first, `2` AMF first, `3` Media Foundation first.
  `zhphone_rec_stats` shows which one recorded the last clip (`Video encoder: h264_amf` ...).
- **32-bit build** `gmcl_zhphone_win32.dll` for the normal (non x86-64) branch of Garry's Mod, the
  same code and features; `install.bat` installs both, the game loads the one of its branch.
- needs the fix69 addon (it knows the build `fix69-multigpu`).


**fix67 (DLL build `fix66-export`):** Save in Photos writes a real **`.mp4`** into
`garrysmod/data/zhunter_saved/` again (the module copies the clip on its own thread; Lua itself
may only write `.dat`, so without this DLL the file is `*.mp4.dat` — rename it to `.mp4`).
Everything else is the same as fix64. Needs the fix67 addon.


A smartphone for the Garry's Mod gamemode **Z-City**: calls, 911, TeleChat, camera, photo/video,
gallery, settings, control centre, clock, music. Standalone addon: Z-City files are not modified.

**fix64 — smooth recording + FXAA:**
- **FXAA on phone videos** (FXAA 3.11, quality preset 39) — done on the GPU inside the encoder
  thread right before NVENC, on the full-resolution frame: no extra in-game FPS cost, no change of
  resolution / bitrate. `zhphone_fxaa 1` (default, sharp), `2` (stronger smoothing), `0` off.
  The live viewfinder and photos are not changed.
- **No freeze when recording starts:** the NVENC session (D3D11 device, encoder, textures, FXAA
  shaders) is prepared in the background while the camera is open; pressing record only switches
  it on. The textures are created one per frame instead of all at once.
- **Less stutter with many addons:** the stutter profiler is off by default (`zhphone_diag 0` —
  before fix64 it wrapped every hook/net/timer of every addon); the phone's hook wrappers no longer
  stack up again and again on top of other addons' wrappers.
- **Phone ear without hitches:** game sound files are read with `file.AsyncRead` (not on the game
  thread) and decoded by the DLL on its own low-priority thread; a sound whose file is still being
  read is placed at the moment it really started (no shift). Often used sounds are pre-loaded
  while the camera is open (`data/stts_phone_ear64.txt`).
- The "ZPhone - fix63 DLL compat" addon is **not needed any more — unsubscribe it** (with the
  fix64 addon it would mute the phone's ear).

**fix62:** phone videos record **real sound** — your microphone (while you talk in voice chat) and
the game's own audio — as AAC inside the MP4, in sync with the video, through the optional native
recorder (H.264 NVENC).

**fix63 — the phone's own ear:** the game sound of a clip is heard **where the phone is**, not at
your head (like the camera in *Content Warning*). Every sound the game starts is re-played by the
native module into the clip at the phone's position: Source's distance fall-off, walls muffle,
far sounds lose their highs, moving sources are followed, pitch and loops as in the game. Sounds
only the server plays (NPCs, doors, other players' steps and shots) are relayed by the server
(fix63 addon needed there). While the phone is at your head (< ~70 units) the clip uses "what you
hear" (with the other players' voice chat), beyond ~170 units only the phone's ear, crossfaded in
between. Not heard by the ear (only near you): other players' voice chat, BASS streams
(`sound.PlayFile` / `PlayURL`: radio, music, Glide engines), map ambients, sounds started before
recording; room DSP/echo is not re-created.

## Install

1. Update the phone addon (fix64) from the Workshop and **unsubscribe "ZPhone - fix63 DLL compat"**.
2. Close Garry's Mod.
3. Run **`install.bat`**. It finds Garry's Mod through Steam (registry, all library folders,
   common folders on every drive), backs up the old DLLs to `GarrysMod\zphone_backup_<date>\`
   and copies **only** the native part (nothing in `garrysmod\addons` is touched):

   | From this package | To |
   |---|---|
   | `garrysmod\lua\bin\gmcl_zhphone_win64.dll` | `GarrysMod\garrysmod\lua\bin\` |
   | `bin\win64\av*-zhphone32-*.dll` (3 files) | `GarrysMod\bin\win64\` |
   | `garrysmod\cfg\zhphone_native.cfg` | `GarrysMod\garrysmod\cfg\` |

   Not found? `install.bat "D:\SteamLibrary\steamapps\common\GarrysMod"` - or copy the
   `garrysmod` and `bin` folders into your `GarrysMod` folder by hand.
4. Start the game and run once in the console: `exec zhphone_native`. After a recording
   `zhphone_rec_stats` shows `Client fix67`, `Native module: fix66-export` and the FXAA mode.

**Server:** only the Workshop addons (no DLL).

## Requirements for the native recorder

- Garry's Mod 64-bit (x86-64 branch) or 32-bit (default branch) — fix69 has both
- best: a GPU with a hardware H.264 encoder: NVIDIA GTX 600+ (NVENC, driver 471.41+), AMD
  Radeon HD 7000+ (AMF, a recent driver; otherwise through Media Foundation), Intel HD 2000+
  (Quick Sync through Media Foundation); default D3D9Ex renderer (no DXVK)
- fix70: any other DirectX 10/11 GPU: CPU path (MJPEG while filming, H.264 after the stop);
  needs Media Foundation for the H.264 step (Windows N: install the Media Feature Pack)
- FXAA: `d3dcompiler_47.dll` (part of Windows 10/11; without it the video is recorded without FXAA)
- Game sound: Windows 10 2004 (build 19041) or newer
- Microphone: Windows Settings → Privacy → Microphone → *Let desktop apps access your microphone*

## Console variables

| Variable | Default | Meaning |
|---|---|---|
| `zhphone_audio` | 1 | 0 = silent clips |
| `zhphone_audio_mic` | 1 | 0 off, 1 only while you talk in voice chat, 2 always |
| `zhphone_audio_game` | 1 | 0 off, 1 Garry's Mod only, 2 + whole-PC sound on older Windows |
| `zhphone_audio_ear` | 1 | fix63: 0 game heard at your head (fix62), 1 at the phone + "what you hear" while it is near you, 2 only at the phone |
| `zhphone_encoder` | 0 | fix69/70: 0 auto (NVENC, AMF, Media Foundation, then CPU), 1 NVENC first, 2 AMF first, 3 Media Foundation first, 4 CPU (MJPEG → H.264 after the stop) |
| `zhphone_fxaa` | 1 | fix64: FXAA on recorded videos — 0 off, 1 quality (sharp), 2 strong |
| `zhphone_diag` | 0 | fix64: 1 = load the stutter profiler on the next reconnect / map change (costs FPS, for measuring only) |
| `zhphone_audio_mic_gain` | 1 | microphone loudness (0–4) |
| `zhphone_audio_play` | 1 | sound when watching clips in the gallery |
| `zhphone_rec_stats` | — | recorder + clip sound state after a recording |

## Uninstall the native part

Close the game, delete `garrysmod\lua\bin\gmcl_zhphone_win64.dll` and the three
`bin\win64\av*-zhphone32-*.dll`.

## Source and licenses

`native_source/` — DLL source (`src/`, FXAA in `src/gpu_fxaa.h`), FFmpeg SDK, build scripts and logs
(`build-info/`), the audio and phone-ear tests (`tests/audio/`, `tests/ear/`), third-party sources
and licenses (`native_source/third-party/`, incl. the NVIDIA FXAA 3.11 notice).

**Status (fix64):** built offline (Windows x64 cross-build, 0 warnings, rebuilt byte for byte from
`native_source/`); the FXAA shaders compile (DXC, SM 6.0) and the FXAA algorithm was checked on test
images; the phone-ear and audio tests pass with ASan/UBSan (background decoding, placement of late sounds),
the Lua simulation of the phone ear passes (async file reading, 70 checks).
**Not tested in-game on Windows / on a GPU yet.**
