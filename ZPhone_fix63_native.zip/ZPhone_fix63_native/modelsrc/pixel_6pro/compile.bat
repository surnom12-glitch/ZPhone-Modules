@echo off
rem ZHUNTER - compiles pixel_6pro.qc with the studiomdl.exe that ships with Garry's Mod
rem and copies the result into stts_content\models\stts\
rem usage: compile.bat                      (Steam path from the registry)
rem        compile.bat "D:\SteamLibrary\steamapps\common\GarrysMod"
setlocal
set "GMOD=%~1"
if not "%GMOD%"=="" goto have
for /f "tokens=2*" %%a in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul') do set "STEAM=%%b"
set "GMOD=%STEAM%\steamapps\common\GarrysMod"
:have
set "GMOD=%GMOD:/=\%"
set "MDL=%GMOD%\bin\studiomdl.exe"
if not exist "%MDL%" set "MDL=%GMOD%\bin\win64\studiomdl.exe"
if not exist "%MDL%" (
	echo studiomdl.exe not found in "%GMOD%\bin"
	echo run: compile.bat "X:\path\to\steamapps\common\GarrysMod"
	pause
	exit /b 1
)
"%MDL%" -game "%GMOD%\garrysmod" -nop4 -verbose "%~dp0pixel_6pro.qc"
if errorlevel 1 ( echo compile FAILED & pause & exit /b 1 )
set "OUT=%~dp0..\..\stts_content\models\stts"
if not exist "%OUT%" mkdir "%OUT%"
copy /y "%GMOD%\garrysmod\models\stts\pixel_6pro.*" "%OUT%\" >nul
echo.
echo done: stts_content\models\stts\pixel_6pro.mdl (+ .vvd .dx90.vtx .phy)
pause
