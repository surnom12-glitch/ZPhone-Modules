@echo off
rem ZHUNTER fix28 - compiles all three phone models (vivo X300 Pro, Pixel 6 Pro, iPhone 18 Pro)
rem usage: compile_all_phones.bat   or   compile_all_phones.bat "D:\SteamLibrary\steamapps\common\GarrysMod"
call "%~dp0vivo_x300pro\compile.bat" %1 <nul
call "%~dp0pixel_6pro\compile.bat" %1 <nul
call "%~dp0iphone_18pro\compile.bat" %1 <nul
echo.
echo all phones done: stts_content\models\stts\
pause
