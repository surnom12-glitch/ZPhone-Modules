import json,struct,numpy as np
CT={5126:np.float32,5123:np.uint16,5125:np.uint32,5121:np.uint8}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}
def load(path):
    d=open(path,'rb').read()
    l=struct.unpack('<I',d[12:16])[0]
    j=json.loads(d[20:20+l])
    off=20+l
    bl=struct.unpack('<I',d[off:off+4])[0]
    binb=d[off+8:off+8+bl]
    def acc(i):
        a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]
        n=NC[a['type']]; dt=CT[a['componentType']]
        start=bv.get('byteOffset',0)+a.get('byteOffset',0)
        stride=bv.get('byteStride',0)
        cnt=a['count']; isz=np.dtype(dt).itemsize*n
        if stride and stride!=isz:
            raw=np.frombuffer(binb,dtype=np.uint8,count=stride*(cnt-1)+isz,offset=start)
            out=np.lib.stride_tricks.as_strided(raw,shape=(cnt,isz),strides=(stride,1)).copy()
            arr=out.view(dt).reshape(cnt,n)
        else:
            arr=np.frombuffer(binb,dtype=dt,count=cnt*n,offset=start).reshape(cnt,n).copy()
        if a.get('normalized'):
            arr=arr.astype(np.float32)/np.iinfo(dt).max
        return arr
    meshes=[]
    for ni,node in enumerate(j['nodes']):
        if 'mesh' not in node: continue
        m=j['meshes'][node['mesh']]
        for p in m['primitives']:
            at=p['attributes']
            meshes.append(dict(name=node['name'],mat=j['materials'][p['material']]['name'],matidx=p['material'],
              pos=acc(at['POSITION']).astype(np.float64),nrm=acc(at['NORMAL']).astype(np.float64),
              uv=acc(at['TEXCOORD_0']).astype(np.float64) if 'TEXCOORD_0' in at else None,
              idx=acc(p['indices']).reshape(-1,3).astype(np.int64)))
    return j,meshes,binb
