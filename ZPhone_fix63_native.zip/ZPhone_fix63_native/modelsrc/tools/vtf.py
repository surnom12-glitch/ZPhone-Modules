# Minimal VTF 7.2 writer. DXT1/DXT5 blocks come from ImageMagick's DDS encoder,
# uncompressed formats are written directly. Mip order in VTF: smallest -> largest.
import struct, subprocess, os, tempfile
from PIL import Image
FMT = {'RGBA8888':0,'BGR888':3,'BGRA8888':12,'DXT1':13,'DXT5':15}
FLAG_CLAMPS,FLAG_CLAMPT,FLAG_ANISO,FLAG_NORMAL,FLAG_NOMIP,FLAG_NOLOD,FLAG_ONEBITALPHA,FLAG_EIGHTBITALPHA=0x4,0x8,0x10,0x80,0x100,0x200,0x1000,0x2000
def mip_dims(w,h):
    out=[(w,h)]
    while w>1 or h>1:
        w=max(1,w//2); h=max(1,h//2); out.append((w,h))
    return out
def dxt_size(w,h,fmt):
    return max(1,(w+3)//4)*max(1,(h+3)//4)*(8 if fmt=='DXT1' else 16)
def _dds_mips(img,fmt,nmips):
    with tempfile.TemporaryDirectory() as td:
        src=os.path.join(td,'in.png'); dst=os.path.join(td,'out.dds')
        img.save(src)
        subprocess.run(['convert',src,'-define','dds:compression='+fmt.lower(),'-define','dds:mipmaps=%d'%(nmips-1),'-define','dds:cluster-fit=true',dst],check=True)
        d=open(dst,'rb').read()
    assert d[:4]==b'DDS '
    h,w=struct.unpack('<II',d[12:20]); mc=struct.unpack('<I',d[28:32])[0]
    data=d[128:]; out=[]; o=0
    for (mw,mh) in mip_dims(w,h)[:nmips]:
        s=dxt_size(mw,mh,fmt); out.append(data[o:o+s]); o+=s
    assert all(len(x)==dxt_size(*wh,fmt) for x,wh in zip(out,mip_dims(w,h))), 'dds mip chain short'
    return out
def write(path,img,fmt='DXT1',flags=0,mips=True,reflect=(0.2,0.2,0.2)):
    img=img.convert('RGBA'); w,h=img.size
    dims=mip_dims(w,h) if mips else [(w,h)]
    if not mips: flags|=FLAG_NOMIP|FLAG_NOLOD
    if fmt in('DXT1','DXT5'):
        levels=_dds_mips(img,fmt,len(dims))
    else:
        levels=[]
        for (mw,mh) in dims:
            im=img.resize((mw,mh),Image.LANCZOS) if (mw,mh)!=(w,h) else img
            r,g,b,a=im.split()
            if fmt=='BGRA8888': levels.append(Image.merge('RGBA',(b,g,r,a)).tobytes())
            elif fmt=='RGBA8888': levels.append(im.tobytes())
            elif fmt=='BGR888': levels.append(Image.merge('RGB',(b,g,r)).tobytes())
    if fmt=='DXT5' or fmt=='BGRA8888' or fmt=='RGBA8888': flags|=FLAG_EIGHTBITALPHA
    hdr=struct.pack('<4sII',b'VTF\0',7,2)+struct.pack('<I',80)
    hdr+=struct.pack('<HHIHH',w,h,flags,1,0)+b'\0'*4
    hdr+=struct.pack('<3f',*reflect)+b'\0'*4
    lw,lh=(16,max(1,16*h//w)) if w>=h else (max(1,16*w//h),16)
    low=_dds_mips(img.resize((lw,lh),Image.LANCZOS),'DXT1',1)[0]
    hdr+=struct.pack('<fIBIBBH',1.0,FMT[fmt],len(levels),13,lw,lh,1)
    hdr=hdr.ljust(80,b'\0')
    with open(path,'wb') as f:
        f.write(hdr); f.write(low)
        for lv in reversed(levels): f.write(lv)
def read_check(path):
    d=open(path,'rb').read()
    sig,v0,v1,hs=struct.unpack('<4sIII',d[:16]); w,h,fl,fr,ff=struct.unpack('<HHIHH',d[16:28])
    fmt,mc,lf=struct.unpack('<IBI',d[52:61]); return dict(sig=sig,ver=(v0,v1),hs=hs,w=w,h=h,flags=hex(fl),fmt=fmt,mips=mc,lowfmt=hex(lf),size=len(d))
