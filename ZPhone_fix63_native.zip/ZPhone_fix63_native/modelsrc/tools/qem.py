# Quadric edge-collapse decimation (Garland-Heckbert) with boundary locking,
# flip / sliver rejection and the link condition (keeps the mesh manifold).
import numpy as np, heapq
from collections import defaultdict
def weld(pos, idx, eps=1e-7):
    key=np.round(pos/eps).astype(np.int64)
    _,first,inv=np.unique(key,axis=0,return_index=True,return_inverse=True)
    inv=inv.reshape(-1)
    return pos[first].copy(), inv[idx]
def _plane(p0,p1,p2):
    n=np.cross(p1-p0,p2-p0); a=np.linalg.norm(n)
    if a<1e-20: return None,0.0
    n/=a; d=-n.dot(p0); return np.array([n[0],n[1],n[2],d]),a*0.5
def decimate(pos, faces, target, boundary_w=1000.0, sharp_w=0.0):
    V=[np.array(p,dtype=np.float64) for p in pos]
    F=[list(f) for f in faces if len(set(f))==3]
    alive=[True]*len(F)
    vf=defaultdict(set)
    for i,f in enumerate(F):
        for v in f: vf[v].add(i)
    Q=[np.zeros((4,4)) for _ in V]
    for f in F:
        pl,a=_plane(V[f[0]],V[f[1]],V[f[2]])
        if pl is None: continue
        K=np.outer(pl,pl)*a
        for v in f: Q[v]+=K
    # boundary edges -> perpendicular constraint planes
    ec=defaultdict(int)
    for f in F:
        for k in range(3):
            a,b=f[k],f[(k+1)%3]; ec[(min(a,b),max(a,b))]+=1
    for f in F:
        pl,_=_plane(V[f[0]],V[f[1]],V[f[2]])
        if pl is None: continue
        for k in range(3):
            a,b=f[k],f[(k+1)%3]
            if ec[(min(a,b),max(a,b))]==1:
                e=V[b]-V[a]; L=np.linalg.norm(e)
                if L<1e-12: continue
                n=np.cross(e,pl[:3]); n/=np.linalg.norm(n)
                p=np.array([n[0],n[1],n[2],-n.dot(V[a])])
                K=np.outer(p,p)*boundary_w*L*L
                Q[a]+=K; Q[b]+=K
    ver=[0]*len(V)
    def nbrs(v):
        s=set()
        for fi in vf[v]: s.update(F[fi])
        s.discard(v); return s
    def best(a,b):
        q=Q[a]+Q[b]
        A=q.copy(); A[3]=[0,0,0,1]
        cands=[V[a],V[b],(V[a]+V[b])*0.5]
        try:
            if abs(np.linalg.det(A))>1e-14:
                x=np.linalg.solve(A,[0,0,0,1])[:3]
                L=np.linalg.norm(V[a]-V[b])
                if np.linalg.norm(x-(V[a]+V[b])*0.5)<L*1.5: cands.insert(0,x)
        except np.linalg.LinAlgError: pass
        bc,bp=None,None
        for c in cands:
            h=np.append(c,1.0); e=h@q@h
            if bc is None or e<bc: bc,bp=e,c
        return max(bc,0.0),bp
    heap=[]
    def push(a,b):
        if a>b: a,b=b,a
        c,p=best(a,b); heapq.heappush(heap,(c,a,b,ver[a],ver[b],tuple(p)))
    seen=set()
    for f in F:
        for k in range(3):
            a,b=f[k],f[(k+1)%3]; e=(min(a,b),max(a,b))
            if e not in seen: seen.add(e); push(*e)
    nf=len(F)
    while nf>target and heap:
        c,a,b,va,vb,p=heapq.heappop(heap)
        if ver[a]!=va or ver[b]!=vb: continue
        shared=vf[a]&vf[b]
        if not shared: continue
        # link condition
        common=nbrs(a)&nbrs(b)
        if len(common)!=len(shared): continue
        p=np.array(p); ok=True
        for fi in (vf[a]|vf[b])-shared:
            f=F[fi]; old=[V[x] for x in f]; new=[p if x in(a,b) else V[x] for x in f]
            n0=np.cross(old[1]-old[0],old[2]-old[0]); n1=np.cross(new[1]-new[0],new[2]-new[0])
            l0=np.linalg.norm(n0); l1=np.linalg.norm(n1)
            if l1<1e-14*max(l0,1e-30)+1e-22: ok=False; break
            if l0>0 and n0.dot(n1)/(l0*l1)<0.5: ok=False; break
            # sliver check
            e2=sum(np.sum((new[i]-new[(i+1)%3])**2) for i in range(3))
            if l1/e2<0.02 and l0/max(sum(np.sum((old[i]-old[(i+1)%3])**2) for i in range(3)),1e-30)>=0.02: ok=False; break
        if not ok: continue
        # collapse b -> a
        V[a]=p; Q[a]=Q[a]+Q[b]
        for fi in shared: alive[fi]=False; nf-=1
        for fi in list(vf[b]):
            if not alive[fi]: continue
            F[fi]=[a if x==b else x for x in F[fi]]
            vf[a].add(fi)
        for fi in shared:
            for x in F[fi]: vf[x].discard(fi)
        vf[b]=set(); vf[a]-=shared
        ver[a]+=1; ver[b]+=1
        for n in nbrs(a): push(a,n)
    outF=[F[i] for i in range(len(F)) if alive[i]]
    used=sorted({v for f in outF for v in f}); remap={v:i for i,v in enumerate(used)}
    return np.array([V[v] for v in used]), np.array([[remap[v] for v in f] for f in outF],dtype=np.int64)
def crease_normals(pos, faces, angle=40.0):
    """per-corner normals, smoothed only across edges flatter than `angle`"""
    p=pos[faces]; fn=np.cross(p[:,1]-p[:,0],p[:,2]-p[:,0])
    area=np.linalg.norm(fn,axis=1); fnu=fn/np.maximum(area[:,None],1e-30)
    vf=defaultdict(list)
    for i,f in enumerate(faces):
        for v in f: vf[v].append(i)
    cosT=np.cos(np.radians(angle)); out=np.zeros((len(faces),3,3))
    for i,f in enumerate(faces):
        for k,v in enumerate(f):
            adj=vf[v]; d=fnu[adj]@fnu[i]; m=np.array(adj)[d>=cosT]
            n=fn[m].sum(0); L=np.linalg.norm(n)
            out[i,k]=n/L if L>0 else fnu[i]
    return out
