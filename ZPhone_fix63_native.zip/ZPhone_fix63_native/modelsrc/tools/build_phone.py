"""ZHUNTER phone model builder (Pixel 6 Pro / iPhone 18 Pro, same pipeline as build_vivo.py).
usage:  python build_phone.py pixel  path/to/pixel_6pro.obj   (mtl + textures next to it)
        python build_phone.py iphone path/to/apple_iphone_18_pro_silver.glb
needs numpy, pillow, ImageMagick 'convert'. writes ./out/<model>/...
Source axes of every phone: +X = top of the phone, +Y = left edge (seen from the front),
+Z = out of the display, 1 unit = 1 inch, origin = middle of the body."""
import sys, os, io, json, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import glb, qem, vtf, objload
from PIL import Image, ImageDraw, ImageFilter

KIND = sys.argv[1]; SRC = sys.argv[2]
INCH = 39.37
# ------------------------------------------------------------------ per model config
if KIND == 'iphone':
    C = dict(key='iphone_18pro', folder='iph18', prefix='iph18', title='Apple iPhone 18 Pro (Silver)', mass=0.36,
        screen='Front_Screen', cover=['Front_Panel'], front_cam='Front_Cam_Lens', back_cam='Back_Cam_Lens', flash='Back_Flash_Light',
        island_parts=['Front_Sensor', 'Front_Cam_Base', 'Front_Cam_Inset', 'Front_Cam_Lens'],
        drop={'Front_Cam_Glass', 'Back_Cam_Glass', 'Back_Flash_Glass', 'Gradient', 'Back_Cam_Lens_Outer'},
        back_parts=['Back_Panel'], body_parts=['Side_Panel'], lod0=15000, lod1=6800, lod2=1500,
        envtint='[0.42 0.42 0.44]', phongboost=3.0, phongexp=30)
elif KIND == 'pixel':
    C = dict(key='pixel_6pro', folder='pix6', prefix='pix6', title='Google Pixel 6 Pro (Stormy Black)', mass=0.37,
        screen='Screen_Plane.002/Screen', cover=['Bezel_Plane.001/Bezel'], front_cam='Lens_Sphere.003/Lens', back_cam='Lens1_Sphere.001/Lens',
        flash='Flash_Circle.005/Flash', island_parts=['Frontcam_Circle.001/CamGray', 'Lens_Sphere.003/Lens'],
        drop={'Frontcam_Circle.001/CamGlass', 'Frame_Plane/CamGlass', 'RecCam_Plane.007/CamGlass'},
        back_parts=['BackBody._Plane.004/Back(top)', 'BackBody._Plane.004/Back(Bottom'], body_parts=['Frame_Plane/Frame'],
        lod0=999999, lod1=5600, lod2=1500, real_h=6.453,  # 163.9 mm
        envtint='[0.35 0.35 0.38]', phongboost=2.6, phongexp=34)
else: raise SystemExit('kind = pixel | iphone')
P_ = C['prefix']; OUT = 'out/' + C['key']; MS = OUT + '/modelsrc/' + C['key']; MAT = OUT + '/materials/models/stts/' + C['folder']
os.makedirs(MS, exist_ok=True); os.makedirs(MAT, exist_ok=True)

def lin2srgb(c): return tuple(int(round(255 * np.clip(x, 0, 1) ** (1 / 2.2))) for x in c[:3])
# ------------------------------------------------------------------ load -> parts in Source axes (not centred yet)
parts = []; mats = {}   # mats[name] = dict(color=(r,g,b), gloss=0..1, tex=Image|None, alpha=float)
if KIND == 'iphone':
    j, meshes, binb = glb.load(SRC)
    def gimg(i):
        bv = j['bufferViews'][j['images'][i]['bufferView']]; o = bv.get('byteOffset', 0)
        return Image.open(io.BytesIO(binb[o:o + bv['byteLength']])).convert('RGBA')
    for m in j['materials']:
        pr = m.get('pbrMetallicRoughness', {}); f = pr.get('baseColorFactor', [1, 1, 1, 1])
        r = pr.get('roughnessFactor', 1); me = pr.get('metallicFactor', 0)
        tex = None
        if 'baseColorTexture' in pr: tex = gimg(j['textures'][pr['baseColorTexture']['index']]['source'])
        mats[m['name']] = dict(color=lin2srgb(f), gloss=float(np.clip((1 - r) ** 2 * (0.35 + 0.65 * me), 0.04, 1)),
            env=float(np.clip((1 - r) * (0.3 + 0.7 * me), 0.03, 1)), tex=tex, alpha=f[3])
    for m in meshes:
        # glTF: x right, y up, z out of the display, metres
        p = m['pos']; n = m['nrm']
        parts.append(dict(name=m['name'], mat=m['mat'], pos=np.stack([p[:, 1], -p[:, 0], p[:, 2]], -1) * INCH,
            nrm=np.stack([n[:, 1], -n[:, 0], n[:, 2]], -1), uv=m['uv'], idx=m['idx']))
else:
    base = os.path.dirname(SRC)
    raw = objload.load(SRC); mt = objload.load_mtl(os.path.splitext(SRC)[0] + '.mtl')
    fr = [p for p in raw if p['name'] == 'Frame_Plane' and p['mat'] == 'Frame'][0]
    S = C['real_h'] / (fr['pos'][:, 1].max() - fr['pos'][:, 1].min())
    for name, m in mt.items():
        kd = m.get('Kd', [0.5] * 3); ns = m.get('Ns', 200)
        gl = float(np.clip((ns / 1000) ** 1.5 * (0.5 + 0.5 * max(m.get('Ks', [0.5])[0], 0)), 0.04, 1))
        tex = None
        if name == 'Lens': tex = Image.open(os.path.join(base, 'cam1.png')).convert('RGBA')
        col = lin2srgb(kd)
        if name == 'Mic': col = (22, 22, 24)               # tiled grille texture -> flat dark grille
        if name == 'Logo': col = (40, 40, 42); gl = 0.55     # the "G" on the back (black on black in the source)
        if name == 'CamGray': col = (24, 24, 26)
        if name == 'Screen': col = (3, 3, 4)
        mats[name] = dict(color=col, gloss=gl, env=float(np.clip(gl * 0.9, 0.03, 1)), tex=tex, alpha=m.get('d', 1))
    for p in raw:
        q = p['pos']; n = p['nrm']
        # OBJ (Blender): x = right edge seen from the BACK (= left seen from the front), y up, display toward -z
        parts.append(dict(name=p['name'] + '/' + p['mat'], mat=p['mat'], pos=np.stack([q[:, 1], q[:, 0], -q[:, 2]], -1) * S,
            nrm=np.stack([n[:, 1], n[:, 0], -n[:, 2]], -1), uv=p['uv'], idx=p['idx']))
byname = {p['name']: p for p in parts}
for k in [C['screen'], C['front_cam'], C['back_cam'], C['flash']] + C['cover'] + C['back_parts'] + C['body_parts'] + C['island_parts']:
    assert k in byname, 'missing part ' + k
parts = [p for p in parts if p['name'] not in C['drop']]
# ------------------------------------------------------------------ centre: X/Y on the body, Z between display and back
body = np.concatenate([byname[n]['pos'] for n in C['body_parts']])
scrP = byname[C['screen']]['pos']; backP = np.concatenate([byname[n]['pos'] for n in C['back_parts']])
cx = (body[:, 0].min() + body[:, 0].max()) / 2; cy = (body[:, 1].min() + body[:, 1].max()) / 2
cz = (scrP[:, 2].max() + backP[:, 2].min()) / 2
for p in parts: p['pos'] = p['pos'] - np.array([cx, cy, cz])
for k in byname: byname[k]['pos'] = byname[k]['pos'] if byname[k] in parts else byname[k]['pos'] - np.array([cx, cy, cz])
scr = byname[C['screen']]; SP = scr['pos']
X0, X1 = SP[:, 0].min(), SP[:, 0].max(); Y0, Y1 = SP[:, 1].min(), SP[:, 1].max(); SZ = SP[:, 2].max()
BACKZ = np.concatenate([byname[n]['pos'] for n in C['back_parts']])[:, 2].min()
print('screen', round(X1 - X0, 4), 'x', round(Y1 - Y0, 4), 'aspect', round((X1 - X0) / (Y1 - Y0), 4), 'z', round(SZ, 4), 'back', round(BACKZ, 4))
# ------------------------------------------------------------------ screen depth map (curved displays) + footprint
R = 160.0  # px per inch
MW, MH = int((Y1 - Y0) * R) + 3, int((X1 - X0) * R) + 3
def to_px(P): return (Y1 - P[..., 1]) * R + 1, (X1 - P[..., 0]) * R + 1  # u = viewer's right, v = down
footprint = Image.new('L', (MW, MH), 0); dr = ImageDraw.Draw(footprint)
for f in scr['idx']:
    u, v = to_px(SP[f]); dr.polygon(list(zip(u, v)), fill=255)
fp = np.array(footprint) > 0
# depth: z of the display at each pixel (nearest vertex height, good enough for the curved edges)
depth = np.full((MH, MW), -1e9)
u, v = to_px(SP); ui = np.clip(u.astype(int), 0, MW - 1); vi = np.clip(v.astype(int), 0, MH - 1)
np.maximum.at(depth, (vi, ui), SP[:, 2])
dimg = Image.fromarray(np.where(depth > -1e8, depth, SZ).astype(np.float32), 'F').filter(ImageFilter.MaxFilter(9))
depth = np.array(dimg)
fpe = np.array(footprint.filter(ImageFilter.MinFilter(5))) > 0
def under_screen(c, eps=0.03):
    u, v = to_px(c); ui = u.astype(int); vi = v.astype(int)
    ok = (ui >= 0) & (vi >= 0) & (ui < MW) & (vi < MH); r = np.zeros(len(c), bool)
    r[ok] = fpe[vi[ok], ui[ok]] & (c[ok, 2] > depth[vi[ok], ui[ok]] - eps)
    return r
for n in C['cover']:
    p = byname[n]; keep = ~under_screen(p['pos'][p['idx']].mean(1)); print(n, ': removed', int((~keep).sum()), 'tris under the display (z-fight)'); p['idx'] = p['idx'][keep]
# island parts sitting in the display plane: lift a hair so nothing z-fights
for n in C['island_parts']:
    p = byname[n]
    if p in parts: p['pos'] = p['pos'].copy(); p['pos'][:, 2] = np.maximum(p['pos'][:, 2], SZ + 0.002) if p['pos'][:, 2].max() >= SZ - 0.004 else p['pos'][:, 2]
# hole of the front camera in the display (UI pixels of the 432 x 960 render target)
holes = (~fp) & (np.array(Image.fromarray(fp.astype(np.uint8) * 255).filter(ImageFilter.MinFilter(1))) == 0)
ys, xs = np.nonzero(~fp)
fc = byname[C['front_cam']]['pos']; fcu, fcv = to_px((fc.min(0) + fc.max(0)) / 2)
# flood the hole around the front camera
from collections import deque
seen = np.zeros_like(fp); q = deque([(int(fcv), int(fcu))]); seen[int(fcv), int(fcu)] = True; pts = []
while q:
    y, x = q.popleft(); pts.append((y, x))
    for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        yy, xx = y + dy, x + dx
        if 0 <= yy < MH and 0 <= xx < MW and not seen[yy, xx] and not fp[yy, xx]: seen[yy, xx] = True; q.append((yy, xx))
    if len(pts) > MW * MH // 4: break
pts = np.array(pts); hy0, hx0 = pts.min(0); hy1, hx1 = pts.max(0)
RTW, RTH = 432, 960
sxu = RTW / (MW - 3); syv = RTH / (MH - 3)
hole = dict(x=float((hx0 - 1) * sxu), y=float((hy0 - 1) * syv), w=float((hx1 - hx0 + 1) * sxu), h=float((hy1 - hy0 + 1) * syv))
print('front camera hole (UI px)', {k: round(v, 1) for k, v in hole.items()})
# ------------------------------------------------------------------ atlas
ATL = 512; atlas = Image.new('RGBA', (ATL, ATL), (20, 20, 20, 40)); nmap = Image.new('RGBA', (256, 256), (128, 128, 255, 40))
patch = {}; slot = 0; px, py = 0, 160
for name, m in mats.items():
    if name not in {p['mat'] for p in parts}: continue
    a = int(255 * m['gloss']); e = int(255 * m['env'])
    if m['tex'] is not None and slot < 4:
        im = m['tex'].resize((128, 128), Image.LANCZOS); bg = Image.new('RGBA', (128, 128), m['color'] + (255,)); bg.alpha_composite(im)
        bg.putalpha(a); atlas.paste(bg, (slot * 128, 0)); nmap.paste(Image.new('RGBA', (64, 64), (128, 128, 255, e)), (slot * 64, 0))
        patch[name] = ('tex', (slot * 128 / ATL + 1 / ATL, 1 / ATL, (slot * 128 + 127) / ATL, 127 / ATL)); slot += 1
    else:
        atlas.paste(Image.new('RGBA', (16, 16), m['color'] + (a,)), (px, py)); nmap.paste(Image.new('RGBA', (8, 8), (128, 128, 255, e)), (px // 2, py // 2))
        patch[name] = ('flat', ((px + 8) / ATL, (py + 8) / ATL)); px += 16
        if px >= ATL: px, py = 0, py + 16
# ------------------------------------------------------------------ LODs
def diag(p): q = p['pos'][p['idx']].reshape(-1, 3); return np.linalg.norm(q.max(0) - q.min(0)) if len(q) else 0
def is_screen(p): return p['name'] == C['screen']
def textured(p): return patch.get(p['mat'], ('',))[0] == 'tex'
def plan(level):
    budget = [C['lod0'], C['lod1'], C['lod2']][level]
    use = []
    for p in parts:
        if len(p['idx']) == 0: continue
        if level == 2 and not is_screen(p) and diag(p) < 0.32 and p['name'] not in C['body_parts'] + C['back_parts']: continue
        if level == 1 and diag(p) < 0.06: continue
        use.append(p)
    fixed = sum(len(p['idx']) for p in use if is_screen(p) or textured(p) or len(p['idx']) <= 48)
    flex = [p for p in use if not (is_screen(p) or textured(p) or len(p['idx']) <= 48)]
    lo, hi = 0.0, 1.0
    for _ in range(40):
        r = (lo + hi) / 2; s = fixed + sum(max(min(len(p['idx']), 48), int(len(p['idx']) * r)) for p in flex)
        if s > budget: hi = r
        else: lo = r
    return use, {id(p): max(min(len(p['idx']), 48), int(len(p['idx']) * lo)) for p in flex}
def corner_uv(p, P, UV):
    if is_screen(p):
        u = (Y1 - P[..., 1]) / (Y1 - Y0); v = (P[..., 0] - X0) / (X1 - X0); return np.stack([u, v], -1)
    k = patch[p['mat']]
    if k[0] == 'flat':
        out = np.zeros(P.shape[:-1] + (2,)); out[..., 0] = k[1][0]; out[..., 1] = 1 - k[1][1]; return out
    r = k[1]; uu = np.clip(UV[..., 0], 0, 1); vv = np.clip(UV[..., 1], 0, 1)
    if KIND == 'pixel': vv = 1 - vv  # OBJ v is up, glTF v is down
    return np.stack([r[0] + uu * (r[2] - r[0]), 1 - (r[1] + vv * (r[3] - r[1]))], -1)
def build_lod(level):
    use, want = plan(level); tris = []; total = 0
    for p in use:
        n = len(p['idx']); w = want.get(id(p), n)
        if w >= n * 0.97 or textured(p) or is_screen(p):
            P = p['pos'][p['idx']]; N = p['nrm'][p['idx']]; UV = None if p['uv'] is None else p['uv'][p['idx']]
        else:
            wp, wf = qem.weld(p['pos'], p['idx'], 1e-5); dp, df = qem.decimate(wp, wf, w)
            if len(df) == 0: continue
            P = dp[df]; N = qem.crease_normals(dp, df, 40.0); UV = None
        uv = corner_uv(p, P, UV)
        tris.append((P_ + ('_screen' if is_screen(p) else '_body'), P, N, uv)); total += len(P)
    print('LOD%d: %d triangles' % (level, total)); return tris, total
# grips: palm targets scaled from the vivo (-0.9, +-1.62, -0.12 on a 6.35 x 3.0 phone)
allp = np.concatenate([p['pos'][p['idx']].reshape(-1, 3) for p in parts if len(p['idx'])]); mn, mx = allp.min(0), allp.max(0)
H, Wd = mx[0] - mn[0], mx[1] - mn[1]
BONES = [('phone_root', -1, (0, 0, 0)), ('grip_l', 0, (-0.9 * H / 6.35, mx[1] + 0.12, BACKZ + 0.2)), ('grip_r', 0, (-0.9 * H / 6.35, mn[1] - 0.12, BACKZ + 0.2))]
def smd_head(f):
    f.write('version 1\nnodes\n')
    for i, (n, pa, _) in enumerate(BONES): f.write('%d "%s" %d\n' % (i, n, pa))
    f.write('end\nskeleton\ntime 0\n')
    for i, (_, _, o) in enumerate(BONES): f.write('%d %.6f %.6f %.6f 0 0 0\n' % (i, *o))
    f.write('end\n')
def write_smd(path, tris):
    with open(path, 'w') as f:
        smd_head(f); f.write('triangles\n')
        for mat, P, N, UV in tris:
            for t in range(len(P)):
                f.write(mat + '\n')
                for k in range(3):
                    p = P[t, k]; n = N[t, k]; n = n / max(np.linalg.norm(n), 1e-9); u = UV[t, k]
                    f.write('0 %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f 1 0 1\n' % (p[0], p[1], p[2], n[0], n[1], n[2], u[0], u[1]))
        f.write('end\n')
lods = [build_lod(i) for i in range(3)]
names = [P_ + '_ref', P_ + '_lod1', P_ + '_lod2']
for i, nm in enumerate(names): write_smd(MS + '/' + nm + '.smd', lods[i][0])
with open(MS + '/' + P_ + '_idle.smd', 'w') as f: smd_head(f)
# physics: one convex box (back plane .. just over the display, like the vivo)
bx0 = np.array([mn[0], mn[1], BACKZ]); bx1 = np.array([mx[0], mx[1], SZ + 0.04])
def box_tris(a, b):
    c = [(x, y, z) for x in (a[0], b[0]) for y in (a[1], b[1]) for z in (a[2], b[2])]
    q = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]; out = []
    ctr = (np.array(a) + np.array(b)) / 2
    for f in q:
        p = [np.array(c[i]) for i in f]; n = np.cross(p[1] - p[0], p[2] - p[0]); n /= np.linalg.norm(n)
        if n.dot(p[0] - ctr) < 0: p = p[::-1]; n = -n
        out += [(p[0], p[1], p[2], n), (p[0], p[2], p[3], n)]
    return out
with open(MS + '/' + P_ + '_phys.smd', 'w') as f:
    smd_head(f); f.write('triangles\n')
    for a, b, c, n in box_tris(bx0, bx1):
        f.write(P_ + '_body\n')
        for p in (a, b, c): f.write('0 %.6f %.6f %.6f %.6f %.6f %.6f 0 0 1 0 1\n' % (*p, *n))
    f.write('end\n')
# ------------------------------------------------------------------ black core (closes holes, must stay INSIDE the body)
# z-range of the model in a vertical column through (x, y): lowest / highest surface
allT = np.concatenate([p['pos'][p['idx']] for p in parts if len(p['idx'])])
def column(x, y):
    a, b, c = allT[:, 0, :2], allT[:, 1, :2], allT[:, 2, :2]; q = np.array([x, y])
    def cr(o, p1, p2): return (p1[:, 0] - o[:, 0]) * (p2[:, 1] - o[:, 1]) - (p1[:, 1] - o[:, 1]) * (p2[:, 0] - o[:, 0])
    Q = np.broadcast_to(q, a.shape)
    d1, d2, d3 = cr(a, b, Q), cr(b, c, Q), cr(c, a, Q)
    hit = ((d1 >= 0) & (d2 >= 0) & (d3 >= 0)) | ((d1 <= 0) & (d2 <= 0) & (d3 <= 0))
    if not hit.any(): return None
    T = allT[hit]; zs = []
    for t in T:
        m = np.array([[t[1, 0] - t[0, 0], t[2, 0] - t[0, 0]], [t[1, 1] - t[0, 1], t[2, 1] - t[0, 1]]])
        try: s = np.linalg.solve(m, q - t[0, :2])
        except np.linalg.LinAlgError: continue
        zs.append(t[0, 2] + s[0] * (t[1, 2] - t[0, 2]) + s[1] * (t[2, 2] - t[0, 2]))
    return (min(zs), max(zs)) if zs else None
hx, hy = (body[:, 0].max() - body[:, 0].min()) / 2, (body[:, 1].max() - body[:, 1].min()) / 2
z0, z1 = BACKZ + 0.10, SZ - 0.06
def core_ok(boxes):
    for a, b in boxes:
        for x in (a[0], b[0]):
            for y in (a[1], b[1]):
                c = column(x, y)
                if c is None or c[0] > a[2] - 0.01 or c[1] < b[2] + 0.01: return False
    return True
inset = 0.10
while True:
    rr = min(hx, hy) * 0.42
    boxes = [((-hx + inset, -hy + inset + rr, z0), (hx - inset, hy - inset - rr, z1)),
             ((-hx + inset + rr, -hy + inset, z0), (hx - inset - rr, hy - inset, z1)),
             ((-hx + inset + rr * 0.3, -hy + inset + rr * 0.3, z0), (hx - inset - rr * 0.3, hy - inset - rr * 0.3, z1))]
    if core_ok(boxes) or inset > 0.6: break
    inset += 0.02
print('core inset', round(inset, 2), 'ok', core_ok(boxes))
# ------------------------------------------------------------------ key points
def ctr(n): p = byname[n]['pos']; return (p.min(0) + p.max(0)) / 2
fcam = ctr(C['front_cam']); bcam = ctr(C['back_cam']); fl = ctr(C['flash'])
geo = dict(model='models/stts/%s.mdl' % C['key'], title=C['title'],
    screen_center=[float((X0 + X1) / 2), float((Y0 + Y1) / 2), float(SZ + 0.002)], screen_w=float(Y1 - Y0), screen_h=float(X1 - X0),
    cam_front=[float(fcam[0]), float(fcam[1]), float(mx[2] + 0.05)], cam_back=[float(bcam[0]), float(bcam[1]), float(mn[2] - 0.05)],
    flash=[float(fl[0]), float(fl[1]), float(byname[C['flash']]['pos'][:, 2].min() - 0.01)],
    bmin=[float(v) for v in mn], bmax=[float(v) for v in mx], back=float(BACKZ), hole=hole,
    core=[[list(map(float, a)), list(map(float, b))] for a, b in boxes], mass=C['mass'])
json.dump(geo, open(OUT + '/geo.json', 'w'), indent=1); print(json.dumps(geo))
# ------------------------------------------------------------------ qc
K = C['key']
qc = f'''// ZHUNTER - {C['title']} phone, compiled for Garry's Mod.
// built by modelsrc/tools/build_phone.py, compile: compile.bat (GarrysMod\\bin\\studiomdl.exe) -> stts_content/models/stts/
$modelname "stts/{K}.mdl"
$cdmaterials "models/stts/{C['folder']}/"
$surfaceprop "computer"
$contents "solid"
$illumposition 0 0 0
$scale 1.0

$body "phone" "{names[0]}.smd"

$lod 10
{{
	replacemodel "{names[0]}.smd" "{names[1]}.smd"
}}
$lod 25
{{
	replacemodel "{names[0]}.smd" "{names[2]}.smd"
}}
$shadowlod
{{
	replacemodel "{names[0]}.smd" "{names[2]}.smd"
}}

// screen: forward = out of the display, up = top of the phone
$attachment "screen" "phone_root" {geo['screen_center'][0]:.4f} {geo['screen_center'][1]:.4f} {geo['screen_center'][2]:.4f} rotate -90 0 180
// selfie camera (forward = out of the display)
$attachment "cam_front" "phone_root" {geo['cam_front'][0]:.4f} {geo['cam_front'][1]:.4f} {geo['cam_front'][2]:.4f} rotate -90 0 180
// main rear camera (forward = out of the back)
$attachment "cam_back" "phone_root" {geo['cam_back'][0]:.4f} {geo['cam_back'][1]:.4f} {geo['cam_back'][2]:.4f} rotate 90 0 0
// palm targets for the hand IK (left / right hand)
$attachment "grip_l" "grip_l" 0 0 0 rotate 0 0 0
$attachment "grip_r" "grip_r" 0 0 0 rotate 0 0 0

$bbox {mn[0]-0.05:.3f} {mn[1]-0.05:.3f} {mn[2]-0.05:.3f} {mx[0]+0.05:.3f} {mx[1]+0.05:.3f} {mx[2]+0.05:.3f}
$cbox {bx0[0]:.3f} {bx0[1]:.3f} {bx0[2]:.3f} {bx1[0]:.3f} {bx1[1]:.3f} {bx1[2]:.3f}

// rotate -90 cancels studiomdl's default 90 degree turn of the root bone (else the phone is landscape)
$sequence "idle" "{P_}_idle.smd" rotate -90 fps 1 loop activity ACT_IDLE 1

$collisionmodel "{P_}_phys.smd"
{{
	$mass {C['mass']}
	$inertia 1.0
	$damping 0.05
	$rotdamping 0.2
}}
'''
open(MS + '/' + K + '.qc', 'w').write(qc)
# ------------------------------------------------------------------ textures + vmt
F_ = C['folder']
atlas.save(OUT + '/atlas_preview.png')
vtf.write(MAT + '/' + P_ + '_body.vtf', atlas, 'DXT5', flags=vtf.FLAG_ANISO)
vtf.write(MAT + '/' + P_ + '_body_n.vtf', nmap, 'DXT5', flags=vtf.FLAG_NORMAL)
off = Image.new('RGBA', (64, 128), (6, 6, 8, 255)); g = ImageDraw.Draw(off)
for y in range(128): g.line([(0, y), (63, y)], fill=(5 + y // 40, 5 + y // 40, 8 + y // 32, 255))
vtf.write(MAT + '/' + P_ + '_screen_off.vtf', off, 'DXT1', flags=vtf.FLAG_CLAMPS | vtf.FLAG_CLAMPT)
open(MAT + '/' + P_ + '_body.vmt', 'w').write(f'''"VertexLitGeneric"
{{
	// {C['title']}: body, frame, camera module, lenses in one atlas -> one draw call
	"$basetexture" "models/stts/{F_}/{P_}_body"
	"$bumpmap" "models/stts/{F_}/{P_}_body_n"
	"$surfaceprop" "computer"
	"$model" "1"

	// alpha of the base texture = per-part gloss
	"$phong" "1"
	"$basemapalphaphongmask" "1"
	"$phongexponent" "{C['phongexp']}"
	"$phongboost" "{C['phongboost']}"
	"$phongfresnelranges" "[0.25 0.6 1]"

	// alpha of the normal map = per-part reflection strength
	"$envmap" "env_cubemap"
	"$normalmapalphaenvmapmask" "1"
	"$envmaptint" "{C['envtint']}"
	"$envmapfresnel" "1"
}}
''')
open(MAT + '/' + P_ + '_screen.vmt', 'w').write(f'''"UnlitGeneric"
{{
	// display. at runtime every phone puts its own render target on this material
	// (SetSubMaterial, cl_shooting_phone_screen.lua). this texture = "screen off".
	"$basetexture" "models/stts/{F_}/{P_}_screen_off"
	"$envmap" "env_cubemap"
	"$envmaptint" "[0.06 0.06 0.06]"
	"$surfaceprop" "glass"
	"$model" "1"
}}
''')
print('done', OUT)
