# Minimal Wavefront OBJ loader: ngons are triangulated by ear clipping in their own
# plane (fan triangulation breaks concave faces like the "G" logo of the Pixel).
import numpy as np
def _earclip(P):
    n=len(P)
    if n==3: return [(0,1,2)]
    # Newell normal -> 2D projection
    N=np.zeros(3)
    for i in range(n):
        a,b=P[i],P[(i+1)%n]; N+=np.array([(a[1]-b[1])*(a[2]+b[2]),(a[2]-b[2])*(a[0]+b[0]),(a[0]-b[0])*(a[1]+b[1])])
    k=int(np.argmax(np.abs(N))); ax=[i for i in range(3) if i!=k]
    Q=P[:,ax].astype(float)
    if N[k]<0: Q[:,0]=-Q[:,0]
    idx=list(range(n)); out=[]
    def cross(o,a,b): return (a[0]-o[0])*(b[1]-o[1])-(a[1]-o[1])*(b[0]-o[0])
    guard=0
    while len(idx)>3 and guard<10000:
        guard+=1; m=len(idx); found=False
        for t in range(m):
            i0,i1,i2=idx[(t-1)%m],idx[t],idx[(t+1)%m]
            a,b,c=Q[i0],Q[i1],Q[i2]
            if cross(a,b,c)<=1e-14: continue
            ok=True
            for j in idx:
                if j in(i0,i1,i2): continue
                p=Q[j]
                if cross(a,b,p)>=0 and cross(b,c,p)>=0 and cross(c,a,p)>=0: ok=False; break
            if ok: out.append((i0,i1,i2)); idx.pop(t); found=True; break
        if not found: # degenerate polygon: fall back to a fan for the rest
            for t in range(1,len(idx)-1): out.append((idx[0],idx[t],idx[t+1]))
            idx=idx[:0]; break
    if len(idx)==3: out.append(tuple(idx))
    return out
def load(path):
    V=[];VT=[];VN=[];groups={}; cur='default'; mat='default'
    for line in open(path,encoding='utf8',errors='ignore'):
        t=line.split()
        if not t: continue
        if t[0]=='v': V.append([float(x) for x in t[1:4]])
        elif t[0]=='vt': VT.append([float(x) for x in t[1:3]])
        elif t[0]=='vn': VN.append([float(x) for x in t[1:4]])
        elif t[0]=='o' or t[0]=='g': cur=t[1] if len(t)>1 else 'default'
        elif t[0]=='usemtl': mat=t[1]
        elif t[0]=='f':
            vs=[]
            for s in t[1:]:
                p=s.split('/'); vs.append((int(p[0])-1,int(p[1])-1 if len(p)>1 and p[1] else -1,int(p[2])-1 if len(p)>2 and p[2] else -1))
            groups.setdefault((cur,mat),[]).append(vs)
    V=np.array(V);VT=np.array(VT) if VT else np.zeros((1,2));VN=np.array(VN) if VN else np.zeros((1,3))
    parts=[]
    for (name,mat),faces in groups.items():
        P=[];N=[];U=[]
        for vs in faces:
            pts=V[[v[0] for v in vs]]
            for (a,b,c) in _earclip(pts):
                for k in (a,b,c):
                    vi,ti,ni=vs[k]; P.append(V[vi]); U.append(VT[ti] if ti>=0 else (0,0)); N.append(VN[ni] if ni>=0 else (0,0,1))
        P=np.array(P,float);N=np.array(N,float);U=np.array(U,float)
        parts.append(dict(name=name,mat=mat,pos=P,nrm=N,uv=U,idx=np.arange(len(P)).reshape(-1,3)))
    return parts
def load_mtl(path):
    mats={};cur=None
    for line in open(path,encoding='utf8',errors='ignore'):
        t=line.split()
        if not t: continue
        if t[0]=='newmtl': cur=line.split(None,1)[1].strip(); mats[cur]={}
        elif cur and t[0] in('Kd','Ks','Ka'): mats[cur][t[0]]=[float(x) for x in t[1:4]]
        elif cur and t[0] in('Ns','d','Ni'): mats[cur][t[0]]=float(t[1])
        elif cur and t[0]=='map_Kd': mats[cur]['map']=line.split(None,1)[1].strip()
    return mats
