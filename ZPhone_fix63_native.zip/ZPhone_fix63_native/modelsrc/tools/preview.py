import numpy as np, sys
from PIL import Image
def load_smd(path):
    L=open(path).read().split('\n'); i=L.index('triangles')+1; T=[]
    while L[i]!='end':
        mat=L[i]; vs=[list(map(float,L[i+k].split()[1:9])) for k in(1,2,3)]; T.append((mat,np.array(vs))); i+=4
    return T
def render(T,atlas,view,W=300,H=640,scale=95, core=None):
    img=np.full((H,W,3),0.55); zb=np.full((H,W),-1e9)
    at=np.asarray(atlas.convert('RGB'),dtype=float)/255
    L=np.array([0.3,0.5,0.8]); L/=np.linalg.norm(L)
    for mat,v in T:
        p=v[:,:3]; n=v[:,3:6]; uv=v[:,6:8]
        if view=='front': sx,sy,sz=-p[:,1],p[:,0],p[:,2]; nn=np.stack([-n[:,1],n[:,0],n[:,2]],-1)
        elif view=='back': sx,sy,sz=p[:,1],p[:,0],-p[:,2]; nn=np.stack([n[:,1],n[:,0],-n[:,2]],-1)
        elif view=='side': sx,sy,sz=p[:,2],p[:,0],p[:,1]; nn=np.stack([n[:,2],n[:,0],n[:,1]],-1)
        else: # 3/4
            a=np.radians(35); c,s=np.cos(a),np.sin(a)
            X=-p[:,1]*c+p[:,2]*s; Z=p[:,1]*s+p[:,2]*c; sx,sy,sz=X,p[:,0],Z
            nn=np.stack([-n[:,1]*c+n[:,2]*s,n[:,0],n[:,1]*s+n[:,2]*c],-1)
        X=sx*scale+W/2; Y=H/2-sy*scale
        x0,x1=int(max(0,np.floor(X.min()))),int(min(W-1,np.ceil(X.max()))); y0,y1=int(max(0,np.floor(Y.min()))),int(min(H-1,np.ceil(Y.max())))
        if x1<x0 or y1<y0: continue
        d=(X[1]-X[0])*(Y[2]-Y[0])-(X[2]-X[0])*(Y[1]-Y[0])
        if abs(d)<1e-12: continue
        xs,ys=np.meshgrid(np.arange(x0,x1+1)+0.5,np.arange(y0,y1+1)+0.5)
        w1=((xs-X[0])*(Y[2]-Y[0])-(X[2]-X[0])*(ys-Y[0]))/d; w2=((X[1]-X[0])*(ys-Y[0])-(xs-X[0])*(Y[1]-Y[0]))/d; w0=1-w1-w2
        m=(w0>=0)&(w1>=0)&(w2>=0)
        if not m.any(): continue
        z=w0*sz[0]+w1*sz[1]+w2*sz[2]
        nrm=w0[...,None]*nn[0]+w1[...,None]*nn[1]+w2[...,None]*nn[2]
        nrm/=np.maximum(np.linalg.norm(nrm,axis=-1,keepdims=True),1e-9)
        sh=np.clip(nrm@L,0,1)*0.7+0.3
        if mat.endswith('_screen'):
            U=w0*uv[0,0]+w1*uv[1,0]+w2*uv[2,0]; V=w0*uv[0,1]+w1*uv[1,1]+w2*uv[2,1]
            col=np.stack([U*0.2+0.05, (1-V)*0.6+0.1, 0.25+0.5*V],-1); sh=np.ones_like(sh)
            # checker to see the UV orientation
            chk=((np.floor(U*6)+np.floor(V*13))%2)*0.15
            col=col+chk[...,None]
            tl=(U<0.12)&(V>0.94); col[tl]=[1,0.2,0.2]
        else:
            U=w0*uv[0,0]+w1*uv[1,0]+w2*uv[2,0]; V=w0*uv[0,1]+w1*uv[1,1]+w2*uv[2,1]
            ix=np.clip((U*at.shape[1]).astype(int),0,at.shape[1]-1); iy=np.clip(((1-V)*at.shape[0]).astype(int),0,at.shape[0]-1)
            col=at[iy,ix]; col=np.clip(col*1.6+0.06,0,1)
        sel=m&(z>zb[y0:y1+1,x0:x1+1])
        zb[y0:y1+1,x0:x1+1][sel]=z[sel]
        img[y0:y1+1,x0:x1+1][sel]=(col*sh[...,None])[sel]
    return Image.fromarray((np.clip(img,0,1)*255).astype(np.uint8))
if __name__=='__main__':
    out=sys.argv[1]; key=sys.argv[2]; pre=sys.argv[3]
    atlas=Image.open(out+'/atlas_preview.png'); rows=[]
    for f in ['_ref','_lod1','_lod2']:
        T=load_smd('%s/modelsrc/%s/%s%s.smd'%(out,key,pre,f))
        rows.append(np.hstack([np.asarray(render(T,atlas,v)) for v in('front','back','side','q')]))
        if f=='_ref':
            big=np.hstack([np.asarray(render(T,atlas,v,W=600,H=1280,scale=190)) for v in('front','back','q')]); Image.fromarray(big).save(out+'/preview_big.png')
    Image.fromarray(np.vstack(rows)).save(out+'/preview_lods.png')
