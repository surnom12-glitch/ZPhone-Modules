import glb, qem, vtf, json, os, numpy as np
from PIL import Image, ImageDraw, ImageFilter
import sys
# usage: python build_vivo.py path/to/vivo_x300_pro_5g_phantom_black.glb  (needs numpy, pillow, ImageMagick 'convert')
SRC=sys.argv[1] if len(sys.argv)>1 else 'vivo_x300_pro_5g_phantom_black.glb'
OUT='out'; MS=OUT+'/modelsrc/vivo_x300pro'; MAT=OUT+'/materials/models/stts/vivo'
os.makedirs(MS,exist_ok=True); os.makedirs(MAT,exist_ok=True)
S=39.37  # 1 unit = 1 inch -> real size (16.1 cm = 6.34 units)
j,meshes,binb=glb.load(SRC)
CY=0.0806
def to_src(p):  # glTF (x right, y up, z out of screen), metres -> Source (X top, Y left, Z screen normal)
    p=np.asarray(p); return np.stack([(p[...,1]-CY)*S,-p[...,0]*S,p[...,2]*S],-1)
def nrm_src(n):
    n=np.asarray(n); return np.stack([n[...,1],-n[...,0],n[...,2]],-1)
# ---------------------------------------------------------------- materials
mats=j['materials']
def srgb(m):
    c=m.get('extras',{}).get('sourceMaterial',{}).get('colors',{}).get('baseColor')
    if c: return (c['r'],c['g'],c['b'])
    f=m['pbrMetallicRoughness'].get('baseColorFactor',[1,1,1,1]); return tuple(int(round(255*max(0,x)**(1/2.2))) for x in f[:3])
def specmask(m):
    pr=m['pbrMetallicRoughness']; r=pr.get('roughnessFactor',1); me=pr.get('metallicFactor',0)
    return float(np.clip((1-r)**2*(0.35+0.65*me),0.04,1.0))
ATL=512; atlas=Image.new('RGBA',(ATL,ATL),(20,20,20,40)); nmap=Image.new('RGBA',(256,256),(128,128,255,40))
patch={}  # material name -> uv rect in atlas (u0,v0,u1,v1) top-left origin

def img_from_gltf(i):
    import io
    bv=j['bufferViews'][j['images'][i]['bufferView']]; o=bv.get('byteOffset',0)
    return Image.open(io.BytesIO(binb[o:o+bv['byteLength']])).convert('RGBA')
lens=img_from_gltf(0).resize((128,128))
TEXTURED={'BASE_Cam_Lens':0,'BASE_Cam_Lens_02':1,'BASE_Cam_Lens_03':2}
for name,slot in TEXTURED.items():
    m=[x for x in mats if x['name']==name][0]; c=srgb(m)
    tint=Image.new('RGBA',(128,128),c+(255,))
    from PIL import ImageChops
    reg=ImageChops.multiply(lens,tint); reg=Image.blend(reg,lens,0.45)
    a=int(255*specmask(m)); reg.putalpha(a)
    atlas.paste(reg,(slot*128,0)); patch[name]=('tex',(slot*128/ATL,0,(slot*128+128)/ATL,128/ATL))
    nmap.paste(Image.new('RGBA',(64,64),(128,128,255,a)),(slot*64,0))
# flat colour patches, 16x16 each, from y=160
px,py=0,160
for m in mats:
    n=m['name']
    if n in TEXTURED or n in('BASE_BC_Deacl_01','COLOUR_Black_BC_Text','COLOUR_Black_BP_Logo','BASE_Glass','COLOUR_Black_Screen'): continue
    c=srgb(m); a=int(255*specmask(m))
    atlas.paste(Image.new('RGBA',(16,16),c+(a,)),(px,py))
    nmap.paste(Image.new('RGBA',(8,8),(128,128,255,a)),(px//2,py//2))
    patch[n]=('flat',((px+8)/ATL,(py+8)/ATL))
    px+=16
    if px>=ATL: px,py=0,py+16
# decal atlas (alpha tested): BC_Decal 256x256 | BC_Text 512x64 | BP_Logo 512x128
dec=Image.new('RGBA',(512,512),(0,0,0,0))
def deca(i,size,pos,name,tint=None):
    im=img_from_gltf(i).resize(size,Image.LANCZOS)
    if tint:
        r,g,b,a=im.split(); im=Image.merge('RGBA',[Image.new('L',size,t) for t in tint]+[a])
    dec.paste(im,pos); patch[name]=('dec',(pos[0]/512,pos[1]/512,(pos[0]+size[0])/512,(pos[1]+size[1])/512))
deca(6,(256,256),(0,0),'BASE_BC_Deacl_01')
deca(7,(512,64),(0,256),'COLOUR_Black_BC_Text',(150,150,150))
deca(8,(512,128),(0,320),'COLOUR_Black_BP_Logo',(120,120,124))
# ---------------------------------------------------------------- geometry
DROP={'Back_Cam_Glass','Front_Cam_Glass'}
TARGET={  # LOD0, LOD1, LOD2 (0 = drop)
 'Side_Panel':(4500,1600,520),'Back_Panel':(1400,480,160),'Front_Screen':(420,140,48),'Front_Display':(700,240,90),
 'Back_Flash_Ref':(260,80,0),'Back_Cam_Black':(560,220,70),'Back_Cam_Base':(560,200,0),'Antenna':(560,220,0),
 'Back_Cam_Border_02':(420,160,60),'Side_Button':(300,120,0),'Back_Flash_Light_01':(220,80,0),'USB_Metal':(160,60,0),
 'Front_Cam_Base':(220,80,0),
}
KEEP2={'Side_Panel','Back_Panel','Front_Screen','Front_Display','Back_Cam_Black','Back_Cam_Border_02','Back_Cam_Border_01','Front_Screen_Border','Back_Cam_Border_01_Camper','Back_Cam_Lens_01','BP_Logo'}
# screen rect (glTF)
scr=[m for m in meshes if m['name']=='Front_Screen'][0]
sx0,sy0=scr['pos'][:,0].min(),scr['pos'][:,1].min(); sx1,sy1=scr['pos'][:,0].max(),scr['pos'][:,1].max()
# rasterise the screen outline -> drop coplanar display triangles under it (z-fight)
R=4000; mask=Image.new('L',(int((sx1-sx0)*R)+3,int((sy1-sy0)*R)+3),0); dr=ImageDraw.Draw(mask)
for f in scr['idx']:
    q=scr['pos'][f]; dr.polygon([((x-sx0)*R+1,(y-sy0)*R+1) for x,y,_ in q],fill=255)
mask=np.array(mask.filter(ImageFilter.MinFilter(5)))
def under_screen(c):
    x=((c[:,0]-sx0)*R+1).astype(int); y=((c[:,1]-sy0)*R+1).astype(int)
    ok=(x>=0)&(y>=0)&(x<mask.shape[1])&(y<mask.shape[0])
    r=np.zeros(len(c),bool); r[ok]=mask[y[ok],x[ok]]>0
    return r&(c[:,2]>0.00395)
parts=[]
for m in meshes:
    if m['name'] in DROP: continue
    idx=m['idx']
    if m['name']=='Front_Display':
        keep=~under_screen(m['pos'][idx].mean(1)); print('front display: removed',(~keep).sum(),'coplanar tris under the screen'); idx=idx[keep]
    parts.append(dict(name=m['name'],mat=m['mat'],pos=m['pos'],nrm=m['nrm'],uv=m['uv'],idx=idx))
def matname(p):
    if p['mat']=='COLOUR_Black_Screen': return 'vivo_screen'
    if patch.get(p['mat'],('',))[0]=='dec': return 'vivo_decal'
    return 'vivo_body'
def corner_uv(p,pos_g,uv,faces):
    kind=patch.get(p['mat'],(None,))[0]
    if p['mat']=='COLOUR_Black_Screen':
        u=(pos_g[...,0]-sx0)/(sx1-sx0); v=(pos_g[...,1]-sy0)/(sy1-sy0); return np.stack([u,v],-1)  # SMD v up = screen top
    if kind=='flat':
        c=patch[p['mat']][1]; out=np.zeros(pos_g.shape[:-1]+(2,)); out[...,0]=c[0]; out[...,1]=1-c[1]; return out
    r=patch[p['mat']][1]; uu=np.clip(uv[...,0],0,1); vv=np.clip(uv[...,1],0,1)
    return np.stack([r[0]+uu*(r[2]-r[0]),1-(r[1]+vv*(r[3]-r[1]))],-1)
def build_lod(level):
    tris=[]; total=0
    for p in parts:
        n=len(p['idx']); tgt=TARGET.get(p['name'])
        if level==2 and p['name'] not in KEEP2 and not (tgt and tgt[2]): continue
        want=n if not tgt else min(n,tgt[level])
        if level==1 and not tgt and n>150: want=int(n*0.55)
        if level==2 and not tgt: want=min(n,max(24,int(n*0.3)))
        textured=patch.get(p['mat'],('',))[0] in('tex','dec')
        if want>=n or textured:
            P=p['pos'][p['idx']]; N=p['nrm'][p['idx']]; UV=None if p['uv'] is None else p['uv'][p['idx']]
        else:
            wp,wf=qem.weld(p['pos'],p['idx']); dp,df=qem.decimate(wp,wf,want)
            P=dp[df]; N=qem.crease_normals(dp,df,40.0); UV=None
        if p['mat']=='COLOUR_Black_Screen' and level==0: P=P.copy(); P[...,2]+=0.000002
        uv=corner_uv(p,P,UV,None)
        tris.append((matname(p),to_src(P),nrm_src(N),uv)); total+=len(P)
    print('LOD%d: %d triangles'%(level,total)); return tris,total
BONES=[('phone_root',-1,(0,0,0)),('grip_l',0,(-0.9,1.62,-0.12)),('grip_r',0,(-0.9,-1.62,-0.12))]
def smd_head(f):
    f.write('version 1\nnodes\n')
    for i,(n,pa,_) in enumerate(BONES): f.write('%d "%s" %d\n'%(i,n,pa))
    f.write('end\nskeleton\ntime 0\n')
    for i,(_,_,o) in enumerate(BONES): f.write('%d %.6f %.6f %.6f 0 0 0\n'%(i,*o))
    f.write('end\n')
def write_smd(path,tris):
    with open(path,'w') as f:
        smd_head(f); f.write('triangles\n')
        for mat,P,N,UV in tris:
            for t in range(len(P)):
                f.write(mat+'\n')
                for k in range(3):
                    p=P[t,k]; n=N[t,k]; n=n/max(np.linalg.norm(n),1e-9); u=UV[t,k]
                    f.write('0 %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f 1 0 1\n'%(p[0],p[1],p[2],n[0],n[1],n[2],u[0],u[1]))
        f.write('end\n')
lods=[build_lod(i) for i in range(3)]
for i,name in enumerate(['vivo_ref','vivo_lod1','vivo_lod2']): write_smd(MS+'/'+name+'.smd',lods[i][0])
with open(MS+'/vivo_idle.smd','w') as f: smd_head(f)
# bounds
allp=np.concatenate([t[1].reshape(-1,3) for t in lods[0][0]]); mn,mx=allp.min(0),allp.max(0); print('bounds',mn.round(3),mx.round(3))
# physics: one convex box, slightly thicker for stable contacts
bx0=np.array([mn[0],mn[1],-0.32]); bx1=np.array([mx[0],mx[1],0.20])
def box_tris(a,b):
    c=[(x,y,z) for x in(a[0],b[0]) for y in(a[1],b[1]) for z in(a[2],b[2])]
    q=[(0,1,3,2),(4,6,7,5),(0,4,5,1),(2,3,7,6),(0,2,6,4),(1,5,7,3)]
    out=[]
    for f in q:
        p=[np.array(c[i]) for i in f]; n=np.cross(p[1]-p[0],p[2]-p[0]); n/=np.linalg.norm(n)
        ctr=(np.array(a)+np.array(b))/2
        if n.dot(p[0]-ctr)<0: p=p[::-1]; n=-n
        out+=[(p[0],p[1],p[2],n),(p[0],p[2],p[3],n)]
    return out
with open(MS+'/vivo_phys.smd','w') as f:
    smd_head(f); f.write('triangles\n')
    for a,b,c,n in box_tris(bx0,bx1):
        f.write('vivo_body\n')
        for p in(a,b,c): f.write('0 %.6f %.6f %.6f %.6f %.6f %.6f 0 0 1 0 1\n'%(*p,*n))
    f.write('end\n')
# ---------------------------------------------------------------- key points (Source units)
def ctr(name):
    m=[m for m in meshes if m['name']==name][0]; return to_src((m['pos'].min(0)+m['pos'].max(0))/2)
scr_c=to_src(np.array([(sx0+sx1)/2,(sy0+sy1)/2,0.004]))
geo=dict(
  screen_center=[float(scr_c[0]),float(scr_c[1]),float(scr_c[2])+0.002],
  screen_w=float((sx1-sx0)*S), screen_h=float((sy1-sy0)*S),
  cam_front=[float(v) for v in ctr('Front_Cam_Lens')], cam_back=[float(v) for v in ctr('Back_Cam_Lens_01')],
  bmin=mn.tolist(), bmax=mx.tolist())
geo['cam_front'][2]=float(mx[2])+0.05; geo['cam_back'][2]=float(mn[2])-0.05
json.dump(geo,open(OUT+'/geo.json','w'),indent=1); print(json.dumps(geo))
qc=f'''// ZHUNTER - vivo X300 Pro (Phantom Black) phone, compiled for Garry's Mod.
// compile: compile.bat (uses GarrysMod\\bin\\studiomdl.exe), output -> stts_content/models/stts/
$modelname "stts/vivo_x300pro.mdl"
$cdmaterials "models/stts/vivo/"
$surfaceprop "computer"
$contents "solid"
$illumposition 0 0 0
$scale 1.0

$body "phone" "vivo_ref.smd"

$lod 10
{{
	replacemodel "vivo_ref.smd" "vivo_lod1.smd"
}}
$lod 25
{{
	replacemodel "vivo_ref.smd" "vivo_lod2.smd"
}}
$shadowlod
{{
	replacemodel "vivo_ref.smd" "vivo_lod2.smd"
}}

// screen: forward = out of the display, up = top of the phone
$attachment "screen" "phone_root" {geo['screen_center'][0]:.4f} {geo['screen_center'][1]:.4f} {geo['screen_center'][2]:.4f} rotate -90 0 180
// selfie camera (forward = out of the display)
$attachment "cam_front" "phone_root" {geo['cam_front'][0]:.4f} {geo['cam_front'][1]:.4f} {geo['cam_front'][2]:.4f} rotate -90 0 180
// main rear camera (forward = out of the back)
$attachment "cam_back" "phone_root" {geo['cam_back'][0]:.4f} {geo['cam_back'][1]:.4f} {geo['cam_back'][2]:.4f} rotate 90 0 0
// palm targets for the hand IK (left / right hand)
$attachment "grip_l" "grip_l" 0 0 0 rotate 0 0 0
$attachment "grip_r" "grip_r" 0 0 0 rotate 0 0 0

$bbox {mn[0]-0.05:.3f} {mn[1]-0.05:.3f} {mn[2]-0.05:.3f} {mx[0]+0.05:.3f} {mx[1]+0.05:.3f} {mx[2]+0.05:.3f}
$cbox {bx0[0]:.3f} {bx0[1]:.3f} {bx0[2]:.3f} {bx1[0]:.3f} {bx1[1]:.3f} {bx1[2]:.3f}

// rotate -90 cancels studiomdl's default 90 degree turn of the root bone (else the phone is landscape)
$sequence "idle" "vivo_idle.smd" rotate -90 fps 1 loop activity ACT_IDLE 1

$collisionmodel "vivo_phys.smd"
{{
	$mass 0.4
	$inertia 1.0
	$damping 0.05
	$rotdamping 0.2
}}
'''
open(MS+'/vivo_x300pro.qc','w').write(qc)
# ---------------------------------------------------------------- textures
atlas.save(OUT+'/atlas_preview.png'); dec.save(OUT+'/decal_preview.png')
vtf.write(MAT+'/vivo_body.vtf',atlas,'DXT5',flags=vtf.FLAG_ANISO)
vtf.write(MAT+'/vivo_body_n.vtf',nmap,'DXT5',flags=vtf.FLAG_NORMAL)
vtf.write(MAT+'/vivo_decal.vtf',dec,'DXT5',flags=vtf.FLAG_ANISO|vtf.FLAG_CLAMPS|vtf.FLAG_CLAMPT)
off=Image.new('RGBA',(64,128),(6,6,8,255)); g=ImageDraw.Draw(off)
for y in range(128): g.line([(0,y),(63,y)],fill=(5+y//40,5+y//40,8+y//32,255))
vtf.write(MAT+'/vivo_screen_off.vtf',off,'DXT1',flags=vtf.FLAG_CLAMPS|vtf.FLAG_CLAMPT)
VMT={
'vivo_body':'''"VertexLitGeneric"
{
	// body, frame, camera island, lenses: one atlas -> one draw call
	"$basetexture" "models/stts/vivo/vivo_body"
	"$bumpmap" "models/stts/vivo/vivo_body_n"
	"$surfaceprop" "computer"
	"$model" "1"

	// alpha of the base texture = per-part gloss (metal frame, glass, lenses)
	"$phong" "1"
	"$basemapalphaphongmask" "1"
	"$phongexponent" "28"
	"$phongboost" "2.5"
	"$phongfresnelranges" "[0.25 0.6 1]"

	// alpha of the normal map = per-part reflection strength
	"$envmap" "env_cubemap"
	"$normalmapalphaenvmapmask" "1"
	"$envmaptint" "[0.35 0.35 0.38]"
	"$envmapfresnel" "1"
}
''',
'vivo_decal':'''"VertexLitGeneric"
{
	// camera ring text, ZEISS badge, back logo (alpha tested, no sorting issues)
	"$basetexture" "models/stts/vivo/vivo_decal"
	"$alphatest" "1"
	"$alphatestreference" "0.5"
	"$allowalphatocoverage" "1"
	"$surfaceprop" "computer"
	"$model" "1"
}
''',
'vivo_screen':'''"UnlitGeneric"
{
	// display. at runtime the phone replaces this material per entity with its
	// own render target (SetSubMaterial), so the UI / camera / video are drawn
	// straight onto this mesh. this texture is only the "screen off" look.
	"$basetexture" "models/stts/vivo/vivo_screen_off"
	"$envmap" "env_cubemap"
	"$envmaptint" "[0.06 0.06 0.06]"
	"$surfaceprop" "glass"
	"$model" "1"
}
'''}
for k,v in VMT.items(): open(MAT+'/'+k+'.vmt','w').write(v)
print('done')
