import numpy as np,sys
from PIL import Image
def load_smd(path):
    L=open(path).read().split('\n'); i=L.index('triangles')+1; tris=[]
    while L[i]!='end':
        mat=L[i]; vs=[list(map(float,L[i+k].split()[1:9])) for k in(1,2,3)]; tris.append((mat,np.array(vs))); i+=4
    return tris
def render(tris,atlas,view,W=420,H=900,scale=130):
    img=np.zeros((H,W,3)); zb=np.full((H,W),-1e9)
    at=np.asarray(atlas.convert('RGB'),dtype=float)/255
    for mat,v in tris:
        p=v[:,:3]; n=v[:,3:6]; uv=v[:,6:8]
        if view=='front': sx,sy,sz=-p[:,1],p[:,0],p[:,2]; ln=n[:,2]
        elif view=='back': sx,sy,sz=p[:,1],p[:,0],-p[:,2]; ln=-n[:,2]
        else: sx,sy,sz=p[:,2]*1,p[:,0],p[:,1]; ln=n[:,1]
        X=sx*scale+W/2; Y=H/2-sy*scale
        x0,x1=int(max(0,np.floor(X.min()))),int(min(W-1,np.ceil(X.max()))); y0,y1=int(max(0,np.floor(Y.min()))),int(min(H-1,np.ceil(Y.max())))
        if x1<x0 or y1<y0: continue
        d=(X[1]-X[0])*(Y[2]-Y[0])-(X[2]-X[0])*(Y[1]-Y[0])
        if abs(d)<1e-12: continue
        xs,ys=np.meshgrid(np.arange(x0,x1+1)+0.5,np.arange(y0,y1+1)+0.5)
        w1=((xs-X[0])*(Y[2]-Y[0])-(X[2]-X[0])*(ys-Y[0]))/d; w2=((X[1]-X[0])*(ys-Y[0])-(xs-X[0])*(Y[1]-Y[0]))/d; w0=1-w1-w2
        m=(w0>=0)&(w1>=0)&(w2>=0)
        if not m.any(): continue
        z=w0*sz[0]+w1*sz[1]+w2*sz[2]; sh=np.clip(w0*ln[0]+w1*ln[1]+w2*ln[2],0,1)*0.75+0.25
        if mat=='vivo_screen': col=np.array([0.1,0.3,0.6])
        elif mat=='vivo_decal': col=np.array([0.9,0.9,0.9])
        else:
            u=uv.mean(0); col=at[int(np.clip((1-u[1])*at.shape[0],0,at.shape[0]-1)),int(np.clip(u[0]*at.shape[1],0,at.shape[1]-1))]
            col=np.clip(col*2.2+0.05,0,1)
        yy,xx=np.nonzero(m); zz=z[m]; better=zz>zb[yy+y0,xx+x0]
        zb[yy[better]+y0,xx[better]+x0]=zz[better]; img[yy[better]+y0,xx[better]+x0]=sh[m][better][:,None]*col
    return Image.fromarray((img*255).astype(np.uint8))
if __name__=='__main__':
    atlas=Image.open('out/atlas_preview.png')
    row=[]
    for f in ['vivo_ref','vivo_lod1','vivo_lod2']:
        t=load_smd('out/modelsrc/vivo_x300pro/%s.smd'%f)
        row.append(np.hstack([np.asarray(render(t,atlas,v)) for v in('front','back','side')]))
    Image.fromarray(np.vstack(row)).resize((630,1350)).save('out/preview.png')
