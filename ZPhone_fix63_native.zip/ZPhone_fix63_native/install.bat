@echo off
setlocal EnableExtensions
title ZPhone for Z-City - native recorder installer
rem ZPhone fix63: installs ONLY the native recorder (DLL + its FFmpeg DLLs + cfg) into Garry's Mod.
rem The addon itself is NOT installed here: subscribe to "ZPhone for Z-City" in the Steam Workshop.
rem Usage: install.bat ["D:\SteamLibrary\steamapps\common\GarrysMod"]
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
set "MARK=garrysmod\lua\bin\gmcl_zhphone_win64.dll"

rem ---- 1. find Garry's Mod
set "GMOD="
if not "%~1"=="" call :tryGmod "%~1"
if defined GMOD goto :found
set "STEAM="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find /i "SteamPath"') do set "STEAM=%%B"
if not defined STEAM for /f "tokens=2,*" %%A in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul ^| find /i "InstallPath"') do set "STEAM=%%B"
if defined STEAM set "STEAM=%STEAM:/=\%"
if defined STEAM call :tryLib "%STEAM%"
if defined GMOD goto :found
if defined STEAM if exist "%STEAM%\steamapps\libraryfolders.vdf" (
  for /f "usebackq tokens=1,*" %%A in ("%STEAM%\steamapps\libraryfolders.vdf") do if /i "%%~A"=="path" call :tryLib "%%~B"
)
if defined GMOD goto :found
for %%D in (C D E F G H) do if not defined GMOD call :tryLib "%%D:\SteamLibrary"
for %%D in (C D E F G H) do if not defined GMOD call :tryLib "%%D:\Steam"
if defined GMOD goto :found
echo Garry's Mod was not found automatically.
set "ASK="
set /p "ASK=Paste the GarrysMod folder (the one with garrysmod and bin inside): "
if defined ASK set "ASK=%ASK:"=%"
if defined ASK call :tryGmod "%ASK%"
if not defined GMOD (
  echo [ERROR] Not a Garry's Mod folder.
  goto :fail
)

:found
echo Garry's Mod: "%GMOD%"

rem ---- 2. the game must be closed (the DLL is locked while it runs)
tasklist /FI "IMAGENAME eq gmod.exe" 2>nul | find /i "gmod.exe" >nul && goto :running
tasklist /FI "IMAGENAME eq hl2.exe" 2>nul | find /i "hl2.exe" >nul && goto :running

if not exist "%GMOD%\bin\win64\" (
  echo [WARNING] "%GMOD%\bin\win64" does not exist: this looks like the 32-bit Garry's Mod.
  echo           The native recorder ^(video quality + sound^) needs the 64-bit build:
  echo           Steam - Garry's Mod - Properties - Betas - "x86-64 - Chromium + 64-bit binaries".
)

rem ---- 3. find the package files (next to install.bat, one folder up/down, or inside the zip it was started from)
set "PKG="
set "ZOUT="
call :findPkg "%SRC%"
if not defined PKG for /d %%D in ("%SRC%\*") do if not defined PKG call :findPkg "%%~fD"
if not defined PKG for %%P in ("%SRC%\..") do call :findPkg "%%~fP"
if not defined PKG call :findPkg "%CD%"
if not defined PKG call :fromZip ""
:askPkg
if defined PKG goto :pkgok
echo The ZPhone files ^(gmcl_zhphone_win64.dll^) were not found next to install.bat.
set "ASK="
set /p "ASK=Drag the ZPhone zip or its unpacked folder into this window and press Enter (empty = cancel): "
if not defined ASK goto :cancel
set "ASK=%ASK:"=%"
call :usePath "%ASK%"
goto :askPkg
:pkgok

rem ---- 4. backup of the old native files
set "STAMP="
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss" 2^>nul') do set "STAMP=%%T"
if not defined STAMP set "STAMP=%RANDOM%%RANDOM%"
set "BK=%GMOD%\zphone_backup_%STAMP%"
set "DIDBK="
if /i not "%PKG%"=="%GMOD%" for %%F in ("%GMOD%\garrysmod\lua\bin\gmcl_zhphone_win64.dll" "%GMOD%\bin\win64\avcodec-zhphone32-62.dll" "%GMOD%\bin\win64\avformat-zhphone32-62.dll" "%GMOD%\bin\win64\avutil-zhphone32-60.dll" "%GMOD%\garrysmod\cfg\zhphone_native.cfg") do (
  if exist %%F (
    mkdir "%BK%" 2>nul
    copy /Y %%F "%BK%\" >nul
    set "DIDBK=1"
  )
)
if defined DIDBK echo Backup of the old files: "%BK%"

rem ---- 5. copy
echo Copying the native recorder...
set "CPERR="
call :put "garrysmod\lua\bin\gmcl_zhphone_win64.dll"
call :put "bin\win64\avcodec-zhphone32-62.dll"
call :put "bin\win64\avformat-zhphone32-62.dll"
call :put "bin\win64\avutil-zhphone32-60.dll"
call :put "garrysmod\cfg\zhphone_native.cfg"
if defined CPERR goto :copyfail
rem files from a downloaded zip carry the "downloaded from the internet" mark: remove it
powershell -NoProfile -Command "Get-ChildItem -LiteralPath ($env:GMOD+'\garrysmod\lua\bin'),($env:GMOD+'\bin\win64') -Filter *zhphone* -ErrorAction SilentlyContinue | Unblock-File" >nul 2>nul
if defined ZOUT rd /s /q "%ZOUT%" 2>nul

echo.
echo Done. Installed:
echo   garrysmod\lua\bin\gmcl_zhphone_win64.dll
echo   bin\win64\avcodec-zhphone32-62.dll, avformat-zhphone32-62.dll, avutil-zhphone32-60.dll
echo   garrysmod\cfg\zhphone_native.cfg
echo.
echo The addon itself: subscribe to "ZPhone for Z-City" in the Steam Workshop ^(the server needs it too, no DLL there^).
if exist "%GMOD%\garrysmod\addons\zcity_phone\" echo [WARNING] An old local copy garrysmod\addons\zcity_phone is still there - delete it, otherwise it is loaded instead of the Workshop version.
echo Start Garry's Mod and type ONCE in the console:  exec zhphone_native
echo After a recording, zhphone_rec_stats shows the recorder and the clip sound state.
echo.
pause
exit /b 0

:cancel
echo Cancelled, nothing was changed.
echo.
pause
exit /b 1
:running
echo [ERROR] Garry's Mod ^(or another Source game^) is running. Close it completely and run install.bat again.
goto :fail
:copyfail
echo [ERROR] A file could not be copied ^(Garry's Mod still running? No write access - run install.bat as administrator^).
goto :fail
:fail
echo.
pause
exit /b 1

rem ---- package helpers
:findPkg
rem %1 = a folder that may be the unpacked package (with garrysmod\lua\bin\gmcl_zhphone_win64.dll)
if defined PKG exit /b 0
if "%~1"=="" exit /b 0
set "TP=%~f1"
if "%TP:~-1%"=="\" set "TP=%TP:~0,-1%"
if exist "%TP%\%MARK%" set "PKG=%TP%"
exit /b 0

:usePath
set "UP=%~f1"
if "%UP:~-1%"=="\" set "UP=%UP:~0,-1%"
if /i "%~x1"==".zip" (
  call :fromZip "%UP%"
  exit /b 0
)
call :findPkg "%UP%"
if not defined PKG for /d %%D in ("%UP%\*") do if not defined PKG call :findPkg "%%~fD"
exit /b 0

:fromZip
rem %1 = zip file, or empty: the zip install.bat was started from (Temp1_<name>.zip) or the newest ZPhone*.zip
rem in Downloads / Desktop / Documents / next to install.bat. It is unpacked to %TEMP%.
set "ZIPIN=%~1"
set "ZOUT="
set "ZDEST=%TEMP%\zphone_pkg_%RANDOM%%RANDOM%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; $z=$env:ZIPIN; if(-not $z){ $s=$env:SRC; $u=$env:USERPROFILE; $d=@(($u+'\Downloads'),[Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('MyDocuments'),$u,(Split-Path $s -Parent),$s) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }; $n=''; if($s -match 'Temp\d+_(.+?\.zip)'){ $n=$matches[1] }; $f=$null; if($n){ $f=Get-ChildItem -LiteralPath $d -Filter $n -File -ErrorAction SilentlyContinue | Select-Object -First 1 }; if(-not $f){ $f=Get-ChildItem -LiteralPath $d -Filter 'ZPhone*.zip' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1 }; if($f){ $z=$f.FullName } }; if($z -and (Test-Path -LiteralPath $z)){ Expand-Archive -LiteralPath $z -DestinationPath $env:ZDEST -Force -ErrorAction Stop }" >nul 2>nul
if exist "%ZDEST%\" set "ZOUT=%ZDEST%"
if not defined ZOUT exit /b 0
echo Unpacked the zip to "%ZOUT%"
call :findPkg "%ZOUT%"
if not defined PKG for /d %%D in ("%ZOUT%\*") do if not defined PKG call :findPkg "%%~fD"
exit /b 0

:put
rem %1 = path relative to the package and to Garry's Mod
if not exist "%PKG%\%~1" exit /b 0
if /i "%PKG%\%~1"=="%GMOD%\%~1" exit /b 0
for %%F in ("%GMOD%\%~1") do if not exist "%%~dpF" mkdir "%%~dpF"
copy /Y "%PKG%\%~1" "%GMOD%\%~1" >nul || set "CPERR=1"
exit /b 0

rem ---- Garry's Mod helpers
:tryLib
if defined GMOD exit /b 0
if "%~1"=="" exit /b 0
set "LIB=%~1"
set "LIB=%LIB:\\=\%"
if exist "%LIB%\steamapps\common\GarrysMod\garrysmod\" set "GMOD=%LIB%\steamapps\common\GarrysMod"
exit /b 0
:tryGmod
if "%~1"=="" exit /b 0
set "TRY=%~1"
if "%TRY:~-1%"=="\" set "TRY=%TRY:~0,-1%"
if exist "%TRY%\garrysmod\gameinfo.txt" (set "GMOD=%TRY%" & exit /b 0)
if exist "%TRY%\gameinfo.txt" if exist "%TRY%\..\garrysmod\" for %%P in ("%TRY%\..") do set "GMOD=%%~fP"
exit /b 0
