fix63 Lua simulation of the phone ear (no GMod needed): harness.lua = small mocks of the GMod API
(Vector, util.TraceLine, net, file, hook, entities, sound, CreateSound, timer) with strict globals.
  pip install lupa
  python3 run.py test_client.lua <addon>/lua/autorun/client/cl_stts_phone_ear63.lua
  python3 run.py test_server.lua "" <addon>/lua/stts_phone/sv_phone_ear.lua
Client (32 checks): Source fall-off, key normalisation, same-frame and client/server dedup, wall ->
quieter + low-pass, quiet far sounds culled, 2D sounds ignored, bad files refused, a loop following a
moving entity, one-shots ended by their length, StopSound / sound-script stop / CSoundPatch FadeOut,
channel replacement, dormant entities at the server's position, 64-voice cap, no net without fix63
on the server. Server (13 checks): nothing sent while nobody films, loud-at-the-phone filter, tick
dedup, entity follow, channel 136, StopSound / CSoundPatch:Stop relayed, 40 msg/s limit, phone held
by another player, opt-out. Result of fix63: PASS.
