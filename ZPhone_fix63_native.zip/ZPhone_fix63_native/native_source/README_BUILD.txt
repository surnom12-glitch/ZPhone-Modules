Native module fix63-phone-ear (gmcl_zhphone_win64.dll). API3, asynchronous GPU capture
(H.264 NVENC, unchanged from fix39) + clip sound (fix62, src/audio_capture.h) + the phone's
own ear (new in fix63, src/phone_ear.h):
 - microphone: WASAPI shared capture of the default Windows recording device;
 - game sound "what you hear": WASAPI process loopback of the Garry's Mod process tree
   (ActivateAudioInterfaceAsync "VAD\Process_Loopback", Windows 10 2004+, loaded at run time);
   optional fallback: loopback of the default playback device (whole PC);
 - fix63 phone ear: Lua reports every sound the game starts (ear_load(key, fileBytes),
   ear_play(id, key, gain, lowpassHz, pitch[, loop]), ear_set(...), ear_stop(id)); the files are
   decoded once (FFmpeg, memory AVIO: WAV PCM / MS-ADPCM / IMA-ADPCM with "cue " loop points,
   MP3, OGG Vorbis; <= 16 MB per file, 192 MB cache) on the recorder thread and mixed into the
   clip by the QPC time of the call: per-voice gain / 2-pole low-pass / pitch with 15 ms
   smoothing, loops, 30 ms stop fades, <= 96 voices, a master ear gain (audio(...,ear));
 - mixed to 48 kHz mono by capture timestamps (QPC) against the video clock, encoded with the
   FFmpeg native AAC encoder (AAC-LC 128 kbit/s) into the same MP4, plus a 24 kHz WAV copy
   for in-game playback. Lua API: start(...,audioFlags 1 mic / 2 game / 4 whole PC / 8 ear),
   capture(t,age), audio(mic,game,muffle[,ear]), ear_*, poll() -> audio, audioMic, audioGame,
   audioWav, audioAAC, audioError, earVoices, earPlayed, earPeak, earFiles, earBadFiles,
   earQueued, earMB ...  build = "fix63-phone-ear", audio_api = 2, ear_api = 1.
No Source SDK interfaces/vtable offsets are used.

BUILD ON WINDOWS: MSVC 2022 Desktop C++, CMake 3.24+, git: run build_windows.bat.
The included ffmpeg-sdk matches the shipped av*-zhphone32 runtime DLLs (fix63 build:
the fix39 FFmpeg n8.1 configuration + --enable-encoder=aac + wav/mp3/ogg demuxers, pcm/adpcm/
mp3/vorbis decoders, mpegaudio/vorbis parsers), see build-info/.
Pinned garrysmod_common and MinHook sources are fetched by CMake; copies in third-party/source.

THE SHIPPED DLL was cross-built on Linux with llvm-mingw 20261006 UCRT, -O2 -g, static C++
runtime: build-info/build_ffmpeg_cross.sh, build-info/build_module_cross.sh,
build-info/module-fix63.log (0 warnings, rebuilt byte for byte), build-info/pe63.json
(SHA-256 + imports).
tests/audio: Linux test of the audio recorder with mocked WASAPI devices (ASan/UBSan PASS).
tests/ear:   Linux test of the phone ear: decoding + mixing (ASan/UBSan PASS).
Windows/GMod gameplay, real WASAPI devices and NVENC were NOT executed in this environment.
FFmpeg source, configure settings, NV headers and licenses are included (third-party/).
