// fix62: + real clip audio (microphone + this game's own sound, see audio_capture.h).
// fix63: + the phone's own ear: game sounds re-played at the phone's position (phone_ear.h).
// fix36: D3D9 command-stream bridge; NO Source interface/vtable calls.
// Gallery JPEG proxies are encoded on the worker only, never on the Lua/render thread.
// Experimental: compiled Windows x64, not validated against a running GMod.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d9.h>
#include <d3d11.h>
#include <dxgi.h>
#include <wincodec.h>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <GarrysMod/Lua/Interface.h>
#include <MinHook.h>
#include "gpu_marker_bridge.h"
#include <cstring>
#include "gpu_thumbnail.h"
extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/hwcontext.h>
#include <libavutil/hwcontext_d3d11va.h>
#include <libavutil/opt.h>
}
#include "audio_capture.h"
#include <array>
#include <atomic>
#include <condition_variable>
#include <filesystem>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <chrono>
static_assert(AV_PIX_FMT_RGB32 == AV_PIX_FMT_BGRA,"Windows little-endian BGRA/NVENC mapping");
using GarrysMod::Lua::ILuaBase;
namespace fs=std::filesystem;
namespace {
constexpr size_t Count=8;
std::atomic<unsigned> hookUsers{0};
struct HookScope {HookScope(){++hookUsers;}~HookScope(){--hookUsers;}};
std::atomic<uint32_t> ticketSerial{1};
std::atomic<IDirect3DDevice9*> observed{nullptr};
std::atomic<bool> unloading{false};
using EndSceneFn=HRESULT(WINAPI*)(IDirect3DDevice9*);
using ResetFn=HRESULT(WINAPI*)(IDirect3DDevice9*,D3DPRESENT_PARAMETERS*);
using ResetExFn=HRESULT(WINAPI*)(IDirect3DDevice9Ex*,D3DPRESENT_PARAMETERS*,D3DDISPLAYMODEEX*);
EndSceneFn originalEnd=nullptr;ResetFn originalReset=nullptr;ResetExFn originalResetEx=nullptr;
void* endAddress=nullptr;void* resetAddress=nullptr;void* resetExAddress=nullptr;
using SetTargetFn=HRESULT(WINAPI*)(IDirect3DDevice9*,DWORD,IDirect3DSurface9*);
using ClearFn=HRESULT(WINAPI*)(IDirect3DDevice9*,DWORD,const D3DRECT*,DWORD,D3DCOLOR,float,DWORD);
SetTargetFn originalTarget=nullptr;ClearFn originalClear=nullptr;
void* targetAddress=nullptr;void* clearAddress=nullptr;
HWND dummyWindow=nullptr;

template<class T>void release(T*& p){if(p){p->Release();p=nullptr;}}
void hr(HRESULT r,const char* op){if(FAILED(r))throw std::runtime_error(std::string(op)+" HRESULT="+std::to_string(uint32_t(r)));}
void check(int r,const char* op){if(r<0){char text[256];av_strerror(r,text,sizeof text);throw std::runtime_error(std::string(op)+": "+text);}}
struct Slot {
 // 0 free, 1 GPU copy outstanding, 2 encoder queued/retained.
 std::atomic<int> state{0},users{0};IDirect3DTexture9* texture=nullptr;IDirect3DSurface9* surface=nullptr;
 IDirect3DQuery9* fence=nullptr;HANDLE handle=nullptr;int64_t pts=0;ULONGLONG issuedAt=0;
};
struct Job {size_t index;int64_t pts;};
struct Ticket {uint32_t color;int64_t pts;ULONGLONG at;};
struct Session {
 int width,height,fps,bitrate;fs::path output,partial;LUID adapter{};
 std::array<Slot,Count> slots;std::mutex mutex;std::condition_variable cv;PhoneGPU::Ring<Job,Count> jobs;std::thread thread;
 bool stopping=false,cancelled=false;std::string error;
 PhoneGPU::Ring<Ticket,Count*2> tickets; // mutex protected, bounded CPU metadata only
 PhoneGPU::Images<IDirect3DSurface9,Count> images;
 std::atomic<int> initState{0}; // 0 idle, 1 initializing, 2 initialized, 3 cancelled before init
 std::atomic<bool> initialized{false},ready{false},workerDone{false},gpuCleaned{true},finishRequested{false};
 std::atomic<uint64_t> submitted{0},encoded{0},dropped{0},copiesReady{0};
 std::atomic<int> galleryMode{0};std::atomic<bool> galleryDirect{false};std::atomic<uint64_t> galleryReadbackBytes{0};
 std::atomic<double> maxSubmitMs{0};IDirect3DDevice9* device=nullptr;
 // fix62: optional clip audio; owned here, its own capture thread
 std::unique_ptr<PhoneAudio::Recorder> audio;std::atomic<bool> audioMuxBroken{false};
 Session(int w,int h,int f,int b,fs::path path):width(w),height(h),fps(f),bitrate(b),output(std::move(path)){partial=output;partial+=L".partial";}
 void endAudio(){if(audio)audio->cancel();}
 void fail(const std::string& text){std::lock_guard<std::mutex> lock(mutex);if(error.empty())error=text;}
 void stop(bool cancel){ {std::lock_guard<std::mutex> lock(mutex);stopping=true;cancelled|=cancel;}cv.notify_all();}
 void cleanGPU(){images.clear();for(auto& slot:slots){release(slot.fence);release(slot.surface);release(slot.texture);}release(device);gpuCleaned=true;}
 ~Session(){stop(true);if(thread.joinable())thread.join();cleanGPU();}
};
std::shared_ptr<Session> current;
std::shared_ptr<Session> getCurrent(){return std::atomic_load(&current);}
fs::path outputPath(const std::string& name){
 if(name.size()<5||name.size()>120||name.find("..")!=std::string::npos||name.substr(name.size()-4)!=".mp4")throw std::runtime_error("invalid filename");
 for(char c:name)if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='_'||c=='-'||c=='.'))throw std::runtime_error("invalid filename");
 wchar_t exe[32768];if(!GetModuleFileNameW(nullptr,exe,32768))throw std::runtime_error("cannot locate game");
 fs::path p=fs::path(exe).parent_path();for(int n=0;n<5;++n,p=p.parent_path())if(fs::is_regular_file(p/L"garrysmod"/L"gameinfo.txt")){
  auto dir=p/L"garrysmod"/L"data"/L"stts_phone_tmp";fs::create_directories(dir);return dir/name;
 }
 throw std::runtime_error("garrysmod/gameinfo.txt not found near executable");
}
// Slots outlive codec and all AVBufferRefs. Buffer data is the stable Slot,
// not a per-frame heap allocation. Callback releases only the slot's GPU lease.
void unlockSlot(void* opaque,uint8_t*){auto slot=static_cast<Slot*>(opaque);if(--slot->users==0)slot->state=0;}
// COM and WIC are private to the encoding worker. Gallery failure must not
// discard a valid MP4. Full-size frames remain GPU-resident for NVENC.
void galleryJPEG(IWICImagingFactory* factory,const D3D11_MAPPED_SUBRESOURCE& mapped,int w,int h,const fs::path& path){
 IWICBitmap* bitmap=nullptr;IWICBitmapScaler* scaler=nullptr;IWICFormatConverter* convert=nullptr;
 IWICStream* stream=nullptr;IWICBitmapEncoder* encoder=nullptr;IWICBitmapFrameEncode* frame=nullptr;IPropertyBag2* props=nullptr;
 try{
  hr(factory->CreateBitmapFromMemory(w,h,GUID_WICPixelFormat32bppBGRA,mapped.RowPitch,mapped.RowPitch*h,static_cast<BYTE*>(mapped.pData),&bitmap),"gallery bitmap");
  if(w!=192||h!=336){hr(factory->CreateBitmapScaler(&scaler),"gallery scaler");hr(scaler->Initialize(bitmap,192,336,WICBitmapInterpolationModeLinear),"gallery resize");}
  hr(factory->CreateFormatConverter(&convert),"gallery converter");hr(convert->Initialize(scaler?static_cast<IWICBitmapSource*>(scaler):static_cast<IWICBitmapSource*>(bitmap),GUID_WICPixelFormat24bppBGR,WICBitmapDitherTypeNone,nullptr,0,WICBitmapPaletteTypeCustom),"gallery format");
  hr(factory->CreateStream(&stream),"gallery stream");hr(stream->InitializeFromFilename(path.c_str(),GENERIC_WRITE),"gallery output");
  hr(factory->CreateEncoder(GUID_ContainerFormatJpeg,nullptr,&encoder),"gallery JPEG");hr(encoder->Initialize(stream,WICBitmapEncoderNoCache),"gallery JPEG init");
  hr(encoder->CreateNewFrame(&frame,&props),"gallery frame");
  PROPBAG2 option{};option.pstrName=const_cast<LPOLESTR>(L"ImageQuality");VARIANT quality{};quality.vt=VT_R4;quality.fltVal=0.86f;
  hr(props->Write(1,&option,&quality),"gallery quality");hr(frame->Initialize(props),"gallery frame init");hr(frame->SetSize(192,336),"gallery dimensions");
  WICPixelFormatGUID format=GUID_WICPixelFormat24bppBGR;hr(frame->SetPixelFormat(&format),"gallery pixel format");
  hr(frame->WriteSource(convert,nullptr),"gallery write");hr(frame->Commit(),"gallery frame commit");hr(encoder->Commit(),"gallery commit");
 }catch(...){release(props);release(frame);release(encoder);release(stream);release(convert);release(scaler);release(bitmap);throw;}
 release(props);release(frame);release(encoder);release(stream);release(convert);release(scaler);release(bitmap);
}
void encode(Session* s){
 AVFormatContext* fmt=nullptr;AVCodecContext* codec=nullptr;AVPacket* packet=nullptr;AVFrame* frame=nullptr;AVStream* astream=nullptr;
 AVBufferRef* deviceRef=nullptr;AVBufferRef* framesRef=nullptr;
 IDXGIFactory1* factory=nullptr;IDXGIAdapter1* adapter=nullptr;ID3D11Device* d11=nullptr;ID3D11DeviceContext* context=nullptr;
 std::array<ID3D11Texture2D*,Count> images{};
 PhoneGPU::Thumbnail thumbnail;
 ID3D11Texture2D* galleryStage=nullptr;IWICImagingFactory* imaging=nullptr;bool com=SUCCEEDED(CoInitializeEx(nullptr,COINIT_MULTITHREADED));
 fs::path galleryDir=s->output;galleryDir.replace_extension(L".proxy");std::ofstream galleryIndex;
 int64_t nextGallery=0,galleryPTS=0;unsigned galleryCount=0;bool galleryEnabled=false;
 size_t galleryPending=Count;
 auto releaseGallery=[&](){if(galleryPending!=Count){auto& slot=s->slots[galleryPending];if(--slot.users==0)slot.state=0;galleryPending=Count;}};
 auto pollGallery=[&](){
  if(galleryPending==Count)return;
  D3D11_MAPPED_SUBRESOURCE mapped{};
  HRESULT rc=context->Map(galleryStage,0,D3D11_MAP_READ,D3D11_MAP_FLAG_DO_NOT_WAIT,&mapped);
  if(rc==DXGI_ERROR_WAS_STILL_DRAWING)return; // retry once on a later frame; never wait/spin
  if(SUCCEEDED(rc)){
   s->galleryReadbackBytes+=uint64_t(mapped.RowPitch)*(s->galleryMode==2?336:s->height);
   try{std::ostringstream name;name<<std::setw(6)<<std::setfill('0')<<galleryCount<<".jpg";
    galleryJPEG(imaging,mapped,s->galleryMode==2?192:s->width,s->galleryMode==2?336:s->height,galleryDir/name.str());
    galleryIndex<<galleryPTS<<" "<<name.str()<<"\n";++galleryCount;
   }catch(...){galleryEnabled=false;}
   context->Unmap(galleryStage,0);
  }else galleryEnabled=false;
  releaseGallery();
 };
 try{
  hr(CreateDXGIFactory1(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(&factory)),"DXGI factory");
  for(UINT n=0;;++n){IDXGIAdapter1* candidate=nullptr;if(factory->EnumAdapters1(n,&candidate)==DXGI_ERROR_NOT_FOUND)break;
   DXGI_ADAPTER_DESC1 desc{};candidate->GetDesc1(&desc);
   if(desc.AdapterLuid.HighPart==s->adapter.HighPart&&desc.AdapterLuid.LowPart==s->adapter.LowPart){adapter=candidate;break;}candidate->Release();
  }
  if(!adapter)throw std::runtime_error("D3D9Ex adapter has no matching DXGI adapter");
  D3D_FEATURE_LEVEL level;hr(D3D11CreateDevice(adapter,D3D_DRIVER_TYPE_UNKNOWN,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT|D3D11_CREATE_DEVICE_VIDEO_SUPPORT,nullptr,0,D3D11_SDK_VERSION,&d11,&level,&context),"D3D11 device");
  for(size_t n=0;n<Count;++n){hr(d11->OpenSharedResource(s->slots[n].handle,__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(&images[n])),"OpenSharedResource D3D9Ex/D3D11");
   D3D11_TEXTURE2D_DESC desc{};images[n]->GetDesc(&desc);if(desc.Format!=DXGI_FORMAT_B8G8R8A8_UNORM||desc.Width!=UINT(s->width)||desc.Height!=UINT(s->height))throw std::runtime_error("shared GPU texture format mismatch");}
  deviceRef=av_hwdevice_ctx_alloc(AV_HWDEVICE_TYPE_D3D11VA);if(!deviceRef)throw std::bad_alloc();
  auto hwdev=reinterpret_cast<AVHWDeviceContext*>(deviceRef->data);auto dctx=static_cast<AVD3D11VADeviceContext*>(hwdev->hwctx);
  dctx->device=d11;d11->AddRef();dctx->device_context=context;context->AddRef();check(av_hwdevice_ctx_init(deviceRef),"FFmpeg D3D11 device");
  framesRef=av_hwframe_ctx_alloc(deviceRef);if(!framesRef)throw std::bad_alloc();
  auto frames=reinterpret_cast<AVHWFramesContext*>(framesRef->data);frames->format=AV_PIX_FMT_D3D11;frames->sw_format=AV_PIX_FMT_BGRA;
  frames->width=s->width;frames->height=s->height;frames->initial_pool_size=0;check(av_hwframe_ctx_init(framesRef),"D3D11 frame description");
  const AVCodec* enc=avcodec_find_encoder_by_name("h264_nvenc");if(!enc)throw std::runtime_error("FFmpeg lacks h264_nvenc");
  check(avformat_alloc_output_context2(&fmt,nullptr,"mp4",s->partial.u8string().c_str()),"MP4 context");if(!fmt)throw std::bad_alloc();
  auto stream=avformat_new_stream(fmt,nullptr);codec=avcodec_alloc_context3(enc);packet=av_packet_alloc();if(!stream||!codec||!packet)throw std::bad_alloc();
  codec->width=s->width;codec->height=s->height;codec->pix_fmt=AV_PIX_FMT_D3D11;codec->hw_frames_ctx=av_buffer_ref(framesRef);if(!codec->hw_frames_ctx)throw std::bad_alloc();
  codec->time_base={1,90000};codec->framerate={s->fps,1};codec->bit_rate=s->bitrate;codec->gop_size=s->fps*2;codec->max_b_frames=0;
  codec->color_range=AVCOL_RANGE_MPEG;codec->colorspace=AVCOL_SPC_BT709;codec->color_primaries=AVCOL_PRI_BT709;codec->color_trc=AVCOL_TRC_BT709;
  if(fmt->oformat->flags&AVFMT_GLOBALHEADER)codec->flags|=AV_CODEC_FLAG_GLOBAL_HEADER;
  AVDictionary* opts=nullptr;av_dict_set(&opts,"preset","p4",0);av_dict_set(&opts,"tune","ll",0);av_dict_set(&opts,"rc","vbr",0);
  av_dict_set(&opts,"cq","20",0);av_dict_set(&opts,"rc-lookahead","0",0);av_dict_set(&opts,"delay","0",0);av_dict_set(&opts,"zerolatency","1",0);av_dict_set(&opts,"surfaces","8",0);
  int result=avcodec_open2(codec,enc,&opts);av_dict_free(&opts);check(result,"NVENC GPU input (driver/format support)");
  stream->time_base=codec->time_base;check(avcodec_parameters_from_context(stream->codecpar,codec),"stream parameters");
  // fix62: AAC track next to the video (absent = old FFmpeg DLLs / audio off)
  if(s->audio&&s->audio->params()){
   astream=avformat_new_stream(fmt,nullptr);
   if(astream&&avcodec_parameters_copy(astream->codecpar,s->audio->params())>=0)astream->time_base={1,PhoneAudio::Rate};
   else{astream=nullptr;s->audioMuxBroken=true;}
  }
  check(avio_open(&fmt->pb,s->partial.u8string().c_str(),AVIO_FLAG_WRITE),"open MP4");check(avformat_write_header(fmt,nullptr),"MP4 header");
  auto drain=[&](){for(;;){int rc=avcodec_receive_packet(codec,packet);if(rc==AVERROR(EAGAIN)||rc==AVERROR_EOF)break;check(rc,"receive NVENC packet");
   av_packet_rescale_ts(packet,codec->time_base,stream->time_base);packet->stream_index=stream->index;
   // with an audio track: written in arrival order (MP4 tracks are independent), never
   // held back by the interleaver while the audio of the last second is still pending
   check(astream?av_write_frame(fmt,packet):av_interleaved_write_frame(fmt,packet),"write MP4 packet");av_packet_unref(packet);++s->encoded;
  }};
  auto writeAudio=[&](){
   if(!astream)return;
   while(AVPacket* a=s->audio->pop()){
    if(!s->audioMuxBroken){
     av_packet_rescale_ts(a,AVRational{1,PhoneAudio::Rate},astream->time_base);a->stream_index=astream->index;
     if(av_write_frame(fmt,a)<0)s->audioMuxBroken=true; // the video is never lost over its sound
    }
    av_packet_free(&a);
   }
  };
  // Optional, bounded 15 FPS browsing proxy. CPU readback/resize/JPEG occurs
  // only here on this worker; a slow worker drops capture slots, never waits
  // for itself from the render thread. There is no screenshot/backbuffer path.
  try{
   hr(CoCreateInstance(CLSID_WICImagingFactory,nullptr,CLSCTX_INPROC_SERVER,IID_PPV_ARGS(&imaging)),"WIC");
   try{thumbnail.init(d11,images,&galleryStage);s->galleryMode=2;s->galleryDirect=thumbnail.directSource();}
   catch(...){
    // Gallery must survive a missing compiler/unsupported shader path. This
    // compatibility fallback is the old worker-only readback, never Lua/GPU hooks.
    release(galleryStage);D3D11_TEXTURE2D_DESC desc{};images[0]->GetDesc(&desc);
    desc.Usage=D3D11_USAGE_STAGING;desc.BindFlags=0;desc.MiscFlags=0;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;
    hr(d11->CreateTexture2D(&desc,nullptr,&galleryStage),"gallery compatibility staging");s->galleryMode=1;
   }
   fs::create_directories(galleryDir);
   galleryIndex.open(galleryDir/L"index.txt",std::ios::trunc);galleryEnabled=bool(galleryIndex);
  }catch(...){galleryEnabled=false;}
  frame=av_frame_alloc();if(!frame)throw std::bad_alloc();
  frame->format=AV_PIX_FMT_D3D11;frame->width=s->width;frame->height=s->height;frame->hw_frames_ctx=av_buffer_ref(framesRef);if(!frame->hw_frames_ctx)throw std::bad_alloc();
  s->ready=true;int64_t last=-1;
  for(;;){Job job;
   {std::unique_lock<std::mutex> lock(s->mutex);s->cv.wait(lock,[&]{return s->stopping||!s->jobs.empty();});
    if(s->cancelled)break;if(s->jobs.empty()){if(s->stopping)break;else continue;}job=s->jobs.front();s->jobs.pop_front();}
   s->slots[job.index].users=1; // encoder ownership, plus an optional gallery lease
   pollGallery();
   if(galleryEnabled&&galleryPending==Count&&job.pts>=nextGallery){
    ++s->slots[job.index].users;galleryPending=job.index;galleryPTS=job.pts;nextGallery=job.pts+6000;
    if(s->galleryMode==2)thumbnail.copy(context,job.index,images[job.index],galleryStage);
    else context->CopyResource(galleryStage,images[job.index]);
    context->Flush(); // submit this WORKER's copy; does not wait for GPU completion
   }
   auto& slot=s->slots[job.index];
   frame->buf[0]=av_buffer_create(reinterpret_cast<uint8_t*>(&slot),sizeof(Slot),unlockSlot,&slot,0);
   if(!frame->buf[0]){if(--slot.users==0)slot.state=0;throw std::bad_alloc();}
   frame->data[0]=reinterpret_cast<uint8_t*>(images[job.index]);frame->data[1]=nullptr;frame->linesize[0]=s->width*4;
   frame->pts=std::max(last+1,job.pts);last=frame->pts;
   int rc=avcodec_send_frame(codec,frame);if(rc==AVERROR(EAGAIN)){drain();rc=avcodec_send_frame(codec,frame);}av_buffer_unref(&frame->buf[0]);check(rc,"submit GPU frame");drain();
   writeAudio();
  }
  pollGallery();
  check(avcodec_send_frame(codec,nullptr),"flush NVENC");drain();
  bool cancelled;{std::lock_guard<std::mutex> lock(s->mutex);cancelled=s->cancelled;}
  if(s->audio){
   // exact clip length = last frame + one frame; the audio thread cuts/pads to it
   if(!cancelled&&s->encoded>0&&last>=0){s->audio->finish(last+90000/std::max(1,s->fps));s->audio->waitDone(20000);}
   else s->audio->cancel();
   writeAudio();
  }
  check(av_write_trailer(fmt),"MP4 trailer");avio_closep(&fmt->pb);
  if(!cancelled&&s->encoded>0)fs::rename(s->partial,s->output);
 }catch(const std::exception& e){s->fail(e.what());}
 s->endAudio();
 releaseGallery();
 av_frame_free(&frame);av_packet_free(&packet);avcodec_free_context(&codec);av_buffer_unref(&framesRef);av_buffer_unref(&deviceRef);
 if(fmt){if(fmt->pb)avio_closep(&fmt->pb);avformat_free_context(fmt);}
 galleryIndex.close();release(imaging);release(galleryStage);
 for(auto& image:images)release(image);release(context);release(d11);release(adapter);release(factory);
 if(com)CoUninitialize();
 {std::error_code ec;fs::remove(s->partial,ec);}s->ready=false;s->workerDone=true;
}
void initialize(Session* s){
 auto d=observed.load();if(!d)throw std::runtime_error("real D3D9 device not observed yet");
 s->device=d;d->AddRef();s->gpuCleaned=false;
 IDirect3DDevice9Ex* ex=nullptr;hr(d->QueryInterface(__uuidof(IDirect3DDevice9Ex),reinterpret_cast<void**>(&ex)),"D3D9Ex required (plain D3D9 unsupported)");ex->Release();
 IDirect3D9* base=nullptr;hr(d->GetDirect3D(&base),"GetDirect3D");IDirect3D9Ex* api=nullptr;
 auto r=base->QueryInterface(__uuidof(IDirect3D9Ex),reinterpret_cast<void**>(&api));base->Release();hr(r,"D3D9Ex API");
 D3DDEVICE_CREATION_PARAMETERS params{};r=d->GetCreationParameters(&params);if(SUCCEEDED(r))r=api->GetAdapterLUID(params.AdapterOrdinal,&s->adapter);api->Release();hr(r,"GetAdapterLUID");
 for(auto& slot:s->slots){hr(d->CreateTexture(s->width,s->height,1,D3DUSAGE_RENDERTARGET,D3DFMT_A8R8G8B8,D3DPOOL_DEFAULT,&slot.texture,&slot.handle),"create shared GPU texture");
  if(!slot.handle)throw std::runtime_error("driver did not return shared GPU handle");hr(slot.texture->GetSurfaceLevel(0,&slot.surface),"shared surface");hr(d->CreateQuery(D3DQUERYTYPE_EVENT,&slot.fence),"GPU event query");}
 s->initialized=true;
 if(s->finishRequested){s->workerDone=true;s->endAudio();}
 else s->thread=std::thread(encode,s);
 s->initState=2;
}
void pump(Session* s){
 if(!s->initialized||s->workerDone||s->gpuCleaned)return;
 for(size_t n=0;n<Count;++n){auto& slot=s->slots[n];if(slot.state!=1)continue;
  // NO FLUSH, NO spin: unfinished work is retried next game frame.
  HRESULT r=slot.fence->GetData(nullptr,0,0);
  if(r==S_OK){{std::lock_guard<std::mutex> lock(s->mutex);if(s->cancelled){slot.state=0;continue;}s->jobs.push_back({n,slot.pts});slot.state=2;}++s->copiesReady;s->cv.notify_one();}
  else if(r==S_FALSE&&GetTickCount64()-slot.issuedAt>5000){s->fail("GPU copy did not complete within 5 seconds");s->stop(true);return;}
  else if(FAILED(r)){s->fail("GPU event query failed (device lost)");s->stop(true);return;}
 }
 if(s->finishRequested){
  bool pending=!s->images.empty();for(auto& slot:s->slots)pending|=slot.state==1;
  {std::lock_guard<std::mutex> lock(s->mutex);pending|=!s->tickets.empty();}
  if(!pending)s->stop(false);
 }
}
// The exact completed phone surface is retained by a tokened command on a
// separate 64x64 marker RT. No marker color is ever drawn into the phone image.
// StretchRect runs AFTER original EndScene, not inside BeginScene/EndScene.
void submit(Session* s,IDirect3DSurface9* source,int64_t pts){
 if(!s->ready||s->workerDone||s->gpuCleaned||!s->device)return;
 size_t n=Count;for(size_t i=0;i<Count;++i){int expected=0;if(s->slots[i].state.compare_exchange_strong(expected,1)){n=i;break;}}
 if(n==Count){++s->dropped;return;}
 auto& slot=s->slots[n];D3DSURFACE_DESC desc{};
 HRESULT rc=source?source->GetDesc(&desc):E_POINTER;
 if(FAILED(rc)||desc.Width!=UINT(s->width)||desc.Height!=UINT(s->height)||desc.MultiSampleType!=D3DMULTISAMPLE_NONE){slot.state=0;s->fail("GPU marker source is not the phone output");s->stop(true);return;}
 LARGE_INTEGER a,b,freq;QueryPerformanceFrequency(&freq);QueryPerformanceCounter(&a);
 rc=s->device->StretchRect(source,nullptr,slot.surface,nullptr,D3DTEXF_NONE);
 if(SUCCEEDED(rc))rc=slot.fence->Issue(D3DISSUE_END);QueryPerformanceCounter(&b);
 s->maxSubmitMs=std::max(s->maxSubmitMs.load(),1000.0*(b.QuadPart-a.QuadPart)/freq.QuadPart);
 if(FAILED(rc)){slot.state=0;s->fail("GPU copy submission failed");s->stop(true);return;}
 slot.pts=pts;slot.issuedAt=GetTickCount64();++s->submitted;
}
HRESULT WINAPI targetHook(IDirect3DDevice9* device,DWORD index,IDirect3DSurface9* surface){
 HookScope guard;
 if(index==0&&surface&&device==observed.load()&&!unloading){
  auto s=getCurrent();if(s&&s->ready&&!s->gpuCleaned){
   D3DSURFACE_DESC to{};
   if(SUCCEEDED(surface->GetDesc(&to))&&to.Width==64&&to.Height==64){
    IDirect3DSurface9* from=nullptr;D3DSURFACE_DESC desc{};
    if(SUCCEEDED(device->GetRenderTarget(0,&from))&&from&&SUCCEEDED(from->GetDesc(&desc))&&desc.Width==UINT(s->width)&&desc.Height==UINT(s->height))s->images.remember(from);
    else if(from!=surface)s->images.remember(nullptr); // preserve source on redundant marker rebind
    release(from);
   }
  }
 }
 return originalTarget(device,index,surface);
}
HRESULT WINAPI clearHook(IDirect3DDevice9* device,DWORD count,const D3DRECT* rects,DWORD flags,D3DCOLOR color,float z,DWORD stencil){
 HookScope guard;
 if(device==observed.load()&&!unloading&&(flags&D3DCLEAR_TARGET)){
  auto s=getCurrent();if(s&&s->ready&&!s->gpuCleaned){
   IDirect3DSurface9* target=nullptr;D3DSURFACE_DESC desc{};
   bool marker=SUCCEEDED(device->GetRenderTarget(0,&target))&&target&&SUCCEEDED(target->GetDesc(&desc))&&desc.Width==64&&desc.Height==64;
   release(target);
   if(marker){
    int64_t pts=-1;
    {std::lock_guard<std::mutex> lock(s->mutex);
     for(size_t i=0;i<s->tickets.size();++i)if(PhoneGPU::matches(s->tickets[i].color,color&0xffffff)){pts=s->tickets[i].pts;s->tickets.erase(i);break;}}
    if(pts>=0){
     try{
      int result=s->images.commit(pts);
      if(result==0)throw std::runtime_error("GPU marker has no preceding phone surface");
      if(result>=2)++s->dropped;
     }catch(const std::exception& e){s->images.remember(nullptr);s->fail(e.what());s->stop(true);}
    }
   }
  }
 }
 return originalClear(device,count,rects,flags,color,z,stencil);
}
void renderTick(IDirect3DDevice9* device){
 auto s=getCurrent();if(!s||unloading)return;
 try{
  int expected=0;
  if(!s->finishRequested&&!s->workerDone&&s->initState.compare_exchange_strong(expected,1))initialize(s.get());
  if(s->initialized&&!s->workerDone&&!s->gpuCleaned){
   bool cancelled;{std::lock_guard<std::mutex> lock(s->mutex);
    cancelled=s->cancelled;auto now=GetTickCount64();
    while(!s->tickets.empty()&&now-s->tickets.front().at>3000){s->tickets.pop_front();++s->dropped;if(s->error.empty())s->error="phone GPU marker was not observed";s->stopping=s->cancelled=true;cancelled=true;}}
   if(cancelled)s->cv.notify_all();
   s->images.drain([&](IDirect3DSurface9* source,int64_t pts){if(!cancelled)submit(s.get(),source,pts);});
   pump(s.get());
  }
  if(s->workerDone&&!s->gpuCleaned)s->cleanGPU();
 }catch(const std::exception& e){s->fail(e.what());s->stop(true);if(!s->thread.joinable()){s->workerDone=true;s->endAudio();}}
}
HRESULT WINAPI endHook(IDirect3DDevice9* device){
 HookScope guard;
 if(!observed&&!unloading){D3DDEVICE_CREATION_PARAMETERS p{};
  if(SUCCEEDED(device->GetCreationParameters(&p))&&p.hFocusWindow!=dummyWindow){DWORD process=0;GetWindowThreadProcessId(p.hFocusWindow,&process);
   RECT bounds{};GetClientRect(p.hFocusWindow,&bounds);
   if(process==GetCurrentProcessId()&&IsWindowVisible(p.hFocusWindow)&&bounds.right>=320&&bounds.bottom>=200){IDirect3DDevice9* expected=nullptr;device->AddRef();if(!observed.compare_exchange_strong(expected,device))device->Release();}
  }
 }
 HRESULT result=originalEnd(device);
 if(SUCCEEDED(result)&&device==observed.load()&&!unloading)renderTick(device);
 return result;
}
void beforeReset(IDirect3DDevice9* device){
 auto s=getCurrent();if(s&&s->device==device&&!s->gpuCleaned){s->fail("D3D9 device reset; recording cancelled");s->finishRequested=true;s->stop(true);s->cleanGPU();}
}
HRESULT WINAPI resetHook(IDirect3DDevice9* device,D3DPRESENT_PARAMETERS* params){HookScope guard;beforeReset(device);return originalReset(device,params);}
HRESULT WINAPI resetExHook(IDirect3DDevice9Ex* device,D3DPRESENT_PARAMETERS* params,D3DDISPLAYMODEEX* mode){HookScope guard;beforeReset(device);return originalResetEx(device,params,mode);}
void installHooks(){
 HMODULE d3d=GetModuleHandleW(L"d3d9.dll");if(!d3d)throw std::runtime_error("D3D9 backend not loaded (DXVK/other renderer not supported)");
 using Create=HRESULT(WINAPI*)(UINT,IDirect3D9Ex**);auto create=reinterpret_cast<Create>(GetProcAddress(d3d,"Direct3DCreate9Ex"));if(!create)throw std::runtime_error("Direct3D9Ex unavailable");
 dummyWindow=CreateWindowExW(0,L"STATIC",L"zhphone probe",WS_POPUP,0,0,16,16,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);if(!dummyWindow)throw std::runtime_error("D3D probe window failed");
 IDirect3D9Ex* api=nullptr;IDirect3DDevice9Ex* dummy=nullptr;HRESULT r=create(D3D_SDK_VERSION,&api);
 if(SUCCEEDED(r)){D3DPRESENT_PARAMETERS p{};p.Windowed=TRUE;p.SwapEffect=D3DSWAPEFFECT_DISCARD;p.hDeviceWindow=dummyWindow;p.BackBufferFormat=D3DFMT_UNKNOWN;
  r=api->CreateDeviceEx(D3DADAPTER_DEFAULT,D3DDEVTYPE_HAL,dummyWindow,D3DCREATE_HARDWARE_VERTEXPROCESSING|D3DCREATE_MULTITHREADED,&p,nullptr,&dummy);}
 if(FAILED(r)){release(api);DestroyWindow(dummyWindow);dummyWindow=nullptr;hr(r,"probe D3D9Ex device");}
 auto table=*reinterpret_cast<void***>(dummy);endAddress=table[42];resetAddress=table[16];resetExAddress=table[132];targetAddress=table[37];clearAddress=table[43]; // documented IDirect3DDevice9 COM order
 auto code=MH_Initialize();if(code!=MH_OK&&code!=MH_ERROR_ALREADY_INITIALIZED){release(dummy);release(api);throw std::runtime_error("MinHook initialization failed");}
 code=MH_CreateHook(endAddress,reinterpret_cast<void*>(endHook),reinterpret_cast<void**>(&originalEnd));
 if(code==MH_OK)code=MH_CreateHook(resetAddress,reinterpret_cast<void*>(resetHook),reinterpret_cast<void**>(&originalReset));
 if(code==MH_OK)code=MH_CreateHook(resetExAddress,reinterpret_cast<void*>(resetExHook),reinterpret_cast<void**>(&originalResetEx));
 if(code==MH_OK)code=MH_CreateHook(targetAddress,reinterpret_cast<void*>(targetHook),reinterpret_cast<void**>(&originalTarget));
 if(code==MH_OK)code=MH_CreateHook(clearAddress,reinterpret_cast<void*>(clearHook),reinterpret_cast<void**>(&originalClear));
 if(code==MH_OK)code=MH_EnableHook(targetAddress);if(code==MH_OK)code=MH_EnableHook(clearAddress);
 if(code==MH_OK)code=MH_EnableHook(endAddress);if(code==MH_OK)code=MH_EnableHook(resetAddress);if(code==MH_OK)code=MH_EnableHook(resetExAddress);
 release(dummy);release(api);DestroyWindow(dummyWindow);dummyWindow=nullptr;
 if(code!=MH_OK)throw std::runtime_error("D3D9 observer hook installation failed (conflicting capture module?)");
}
bool removeHooks(){
 void* addresses[]={endAddress,resetAddress,resetExAddress,targetAddress,clearAddress};
 for(auto p:addresses)if(p)MH_DisableHook(p);
 auto deadline=GetTickCount64()+5000;
 while(hookUsers&&GetTickCount64()<deadline)Sleep(1); // unload only, NEVER recording
 if(hookUsers){HMODULE pinned=nullptr;GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,reinterpret_cast<LPCWSTR>(&endHook),&pinned);return false;}
 for(auto p:addresses)if(p)MH_RemoveHook(p);
 endAddress=resetAddress=resetExAddress=targetAddress=clearAddress=nullptr;
 auto d=observed.exchange(nullptr);if(d)d->Release();return true;
}
int answer(ILuaBase* L,bool ok,const char* why=nullptr){L->PushBool(ok);if(why){L->PushString(why);return 2;}return 1;}
LUA_FUNCTION(start){
 const char* name=LUA->CheckString(1);int w=int(LUA->CheckNumber(2)),h=int(LUA->CheckNumber(3)),fps=int(LUA->CheckNumber(4)),bitrate=int(LUA->CheckNumber(5));
 int audioFlags=LUA->IsType(6,GarrysMod::Lua::Type::Number)?int(LUA->GetNumber(6))&15:0; // fix62: 1 mic, 2 game, 4 whole-device fallback; fix63: 8 the phone's ear
 auto previous=getCurrent();if(previous&&(!previous->workerDone||!previous->gpuCleaned))return answer(LUA,false,"recorder busy");
 if(w<64||h<64||w>1920||h>1920||(w&1)||(h&1)||fps<1||fps>60||bitrate<500000||bitrate>50000000)return answer(LUA,false,"invalid dimensions/rate");
 try{auto s=std::make_shared<Session>(w,h,fps,bitrate,outputPath(name));
  if(audioFlags){fs::path wav=s->output;wav.replace_extension(L".wav");std::error_code ec;fs::remove(wav,ec);s->audio=std::make_unique<PhoneAudio::Recorder>(audioFlags,wav);}
  std::atomic_store(&current,s);return answer(LUA,true);}catch(const std::exception& e){return answer(LUA,false,e.what());}
}
LUA_FUNCTION(capture){
 double t=LUA->CheckNumber(1);auto s=getCurrent();if(!s||s->workerDone)return answer(LUA,false,"not recording");
 if(!std::isfinite(t)||t<0||t>600)return answer(LUA,false,"invalid timestamp");
 if(s->audio&&!s->finishRequested){
  // fix62: arg 2 = how old this image is (s); pts 0 on the QPC clock, set once
  double age=LUA->IsType(2,GarrysMod::Lua::Type::Number)?LUA->GetNumber(2):0;if(!std::isfinite(age)||age<0||age>5)age=0;
  s->audio->zero(PhoneAudio::now100()-int64_t(std::llround((age+t)*1e7)));s->audio->seen(t);
 }
 if(!s->ready)return answer(LUA,false,"starting");if(s->finishRequested)return answer(LUA,false,"stopping");
 uint32_t color=PhoneGPU::markerColor(ticketSerial.fetch_add(1));
 {std::lock_guard<std::mutex> lock(s->mutex);
  if(s->tickets.size()>=Count*2){++s->dropped;return answer(LUA,false,"queue full");}
  s->tickets.push_back({color,int64_t(std::llround(t*90000)),GetTickCount64()});}
 LUA->PushBool(true);LUA->PushNumber(color);return 2;
}
void stopEarly(std::shared_ptr<Session> s,bool cancel){
 s->finishRequested=true;
 if(cancel||!s->initialized)s->stop(true);
 int expected=0;if(s->initState.compare_exchange_strong(expected,3)){s->workerDone=true;s->endAudio();}
 if(cancel)s->endAudio();
}
LUA_FUNCTION(finish){if(auto s=getCurrent())stopEarly(s,false);return 0;}
// fix62: audio(micGain, gameGain, muffle[, earGain]) every frame while filming. No I/O, atomics only.
LUA_FUNCTION(audio){
 auto s=getCurrent();if(!s||!s->audio||s->workerDone){LUA->PushBool(false);return 1;}
 s->audio->control(LUA->CheckNumber(1),LUA->CheckNumber(2),LUA->IsType(3,GarrysMod::Lua::Type::Number)?LUA->GetNumber(3):0,
  LUA->IsType(4,GarrysMod::Lua::Type::Number)?LUA->GetNumber(4):0);
 LUA->PushBool(true);return 1;
}
// fix63: the phone's own ear (phone_ear.h). ear_load(key, fileBytes) -> 1 queued, 2 known, 3 refused
LUA_FUNCTION(ear_load){
 unsigned int len=0;const char* key=LUA->CheckString(1);const char* data=LUA->GetString(2,&len);
 if(!data){LUA->PushNumber(3);return 1;}
 LUA->PushNumber(PhoneEar::bank().add(key,std::string(data,len)));return 1;
}
// ear_state(key) -> 0 unknown / 1 decoding / 2 ready / 3 unusable, seconds, loops
LUA_FUNCTION(ear_state){
 double seconds=0;bool loop=false;int st=PhoneEar::bank().state(LUA->CheckString(1),&seconds,&loop);
 LUA->PushNumber(st);LUA->PushNumber(seconds);LUA->PushBool(loop);return 3;
}
// ear_play(id, key, gain, lowpassHz, pitch[, loop]) -> 0 not filming, 1 playing, 2 send the file first, 3 unusable file
LUA_FUNCTION(ear_play){
 auto s=getCurrent();if(!s||!s->audio||s->workerDone){LUA->PushNumber(0);return 1;}
 int id=int(LUA->CheckNumber(1));std::string key=LUA->CheckString(2);
 int st=PhoneEar::bank().state(key);
 if(st==PhoneEar::Unknown){LUA->PushNumber(2);return 1;}
 if(st==PhoneEar::Failed){LUA->PushNumber(3);return 1;}
 bool loop=!LUA->IsType(6,GarrysMod::Lua::Type::Bool)||LUA->GetBool(6);
 s->audio->earPlay(id,key,LUA->CheckNumber(3),LUA->CheckNumber(4),LUA->CheckNumber(5),loop);
 LUA->PushNumber(1);return 1;
}
LUA_FUNCTION(ear_set){
 auto s=getCurrent();if(!s||!s->audio||s->workerDone)return 0;
 s->audio->earSet(int(LUA->CheckNumber(1)),LUA->CheckNumber(2),LUA->CheckNumber(3),LUA->CheckNumber(4));return 0;
}
LUA_FUNCTION(ear_stop){
 auto s=getCurrent();if(!s||!s->audio||s->workerDone)return 0;
 s->audio->earStop(int(LUA->CheckNumber(1)));return 0;
}
LUA_FUNCTION(cancel){if(auto s=getCurrent())stopEarly(s,true);return 0;}
LUA_FUNCTION(poll){
 // Plain statistics snapshot. NEVER calls any Source/renderer interface.
 auto s=getCurrent();
 LUA->CreateTable();auto boolean=[&](const char* k,bool v){LUA->PushBool(v);LUA->SetField(-2,k);};auto number=[&](const char* k,double v){LUA->PushNumber(v);LUA->SetField(-2,k);};
 boolean("ready",s&&s->ready);boolean("done",!s||(s->workerDone&&s->gpuCleaned));boolean("async_gpu",true);
 number("submitted",s?double(s->submitted.load()):0);number("encoded",s?double(s->encoded.load()):0);number("dropped",s?double(s->dropped.load()):0);
 boolean("galleryDirect",s&&s->galleryDirect);number("galleryMode",s?double(s->galleryMode.load()):0);number("galleryReadbackBytes",s?double(s->galleryReadbackBytes.load()):0);
 number("gpuCopiesReady",s?double(s->copiesReady.load()):0);number("maxSubmitMs",s?s->maxSubmitMs.load():0);
 std::string error;if(s){std::lock_guard<std::mutex> lock(s->mutex);error=s->error;number("pending",double(s->jobs.size()));number("pendingMarkers",double(s->tickets.size()));}
 boolean("audio",s&&s->audio);
 if(s&&s->audio){auto a=s->audio->stats();
  number("audioMic",a.mic);number("audioGame",a.game);number("audioSamples",a.samples);number("audioMicPeak",a.micPeak);number("audioGamePeak",a.gamePeak);
  boolean("audioWav",a.wav);boolean("audioAAC",a.aac&&!s->audioMuxBroken);LUA->PushString(a.error.c_str());LUA->SetField(-2,"audioError");
  number("earVoices",a.earVoices);number("earPlayed",a.earPlayed);number("earPeak",a.earPeak);}
 {int ready=0,failed=0,queued=0;double mb=0;PhoneEar::bank().stats(ready,failed,queued,mb);
  number("earFiles",ready);number("earBadFiles",failed);number("earQueued",queued);number("earMB",mb);}
 LUA->PushString(error.c_str());LUA->SetField(-2,"error");return 1;
}
}
GMOD_MODULE_OPEN(){
 try{
  unloading=false;av_log_set_level(AV_LOG_QUIET);
  installHooks();
 }catch(const std::exception& e){removeHooks();LUA->ThrowError(e.what());return 0;}
 LUA->CreateTable();LUA->PushNumber(3);LUA->SetField(-2,"api_version");LUA->PushBool(true);LUA->SetField(-2,"async_gpu");LUA->PushString("fix63-phone-ear");LUA->SetField(-2,"build");LUA->PushNumber(2);LUA->SetField(-2,"audio_api");LUA->PushNumber(1);LUA->SetField(-2,"ear_api");
 #define FN(name) LUA->PushCFunction(name);LUA->SetField(-2,#name)
 FN(start);FN(capture);FN(finish);FN(cancel);FN(poll);FN(audio);FN(ear_load);FN(ear_state);FN(ear_play);FN(ear_set);FN(ear_stop);
 LUA->PushSpecial(GarrysMod::Lua::SPECIAL_GLOB);LUA->Push(-2);LUA->SetField(-2,"zhphone");LUA->Pop();
 #undef FN
 return 1;
}
GMOD_MODULE_CLOSE(){
 unloading=true;auto s=getCurrent();if(s)stopEarly(s,true);
 if(!removeHooks())return 0; // pinned until process exit if a hook is still active
 if(s){if(s->thread.joinable())s->thread.join();s->workerDone=true;s->cleanGPU();}
 std::atomic_store(&current,std::shared_ptr<Session>{});PhoneEar::bank().clear();return 0;
}
