@echo off
setlocal EnableExtensions
title ZPhone for Z-City - installer
rem ZPhone fix63 installer: copies the addon, the native recorder DLL, its FFmpeg DLLs and the cfg
rem into Garry's Mod. Usage: install.bat ["D:\SteamLibrary\steamapps\common\GarrysMod"]
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"
if not exist "%SRC%\garrysmod\addons\zcity_phone\addon.json" (
  echo [ERROR] Run install.bat from the unpacked package folder: garrysmod\addons\zcity_phone was not found next to it.
  goto :fail
)

rem ---- 1. find Garry's Mod
set "GMOD="
if not "%~1"=="" call :tryGmod "%~1"
if defined GMOD goto :found
set "STEAM="
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamPath 2^>nul ^| find /i "SteamPath"') do set "STEAM=%%B"
if not defined STEAM for /f "tokens=2,*" %%A in ('reg query "HKLM\SOFTWARE\WOW6432Node\Valve\Steam" /v InstallPath 2^>nul ^| find /i "InstallPath"') do set "STEAM=%%B"
if defined STEAM set "STEAM=%STEAM:/=\%"
if defined STEAM call :tryLib "%STEAM%"
if defined GMOD goto :found
if defined STEAM if exist "%STEAM%\steamapps\libraryfolders.vdf" (
  for /f "usebackq tokens=1,*" %%A in ("%STEAM%\steamapps\libraryfolders.vdf") do if /i "%%~A"=="path" call :tryLib "%%~B"
)
if defined GMOD goto :found
for %%D in (C D E F G H) do if not defined GMOD call :tryLib "%%D:\SteamLibrary"
for %%D in (C D E F G H) do if not defined GMOD call :tryLib "%%D:\Steam"
if defined GMOD goto :found
echo Garry's Mod was not found automatically.
set "ASK="
set /p "ASK=Paste the GarrysMod folder (the one with garrysmod and bin inside): "
if defined ASK set "ASK=%ASK:"=%"
if defined ASK call :tryGmod "%ASK%"
if not defined GMOD (
  echo [ERROR] Not a Garry's Mod folder.
  goto :fail
)

:found
echo Garry's Mod: "%GMOD%"

rem ---- 2. the game must be closed (the DLL is locked while it runs)
tasklist /FI "IMAGENAME eq gmod.exe" 2>nul | find /i "gmod.exe" >nul && goto :running
tasklist /FI "IMAGENAME eq hl2.exe" 2>nul | find /i "hl2.exe" >nul && goto :running

if not exist "%GMOD%\bin\win64\" (
  echo [WARNING] "%GMOD%\bin\win64" does not exist: this looks like the 32-bit Garry's Mod.
  echo           The native recorder ^(video quality + sound^) needs the 64-bit build:
  echo           Steam - Garry's Mod - Properties - Betas - "x86-64 - Chromium + 64-bit binaries".
  echo           The addon itself is installed anyway ^(it works without the DLL, silent low-res clips^).
)

rem ---- 3. backup of what gets replaced
set "STAMP="
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss" 2^>nul') do set "STAMP=%%T"
if not defined STAMP set "STAMP=%RANDOM%%RANDOM%"
set "BK=%GMOD%\zphone_backup_%STAMP%"
set "DIDBK="
if exist "%GMOD%\garrysmod\addons\zcity_phone\" (
  mkdir "%BK%\addons" 2>nul
  move "%GMOD%\garrysmod\addons\zcity_phone" "%BK%\addons\zcity_phone" >nul || (
    echo [ERROR] Could not move the old garrysmod\addons\zcity_phone ^(a file is open?^).
    goto :fail
  )
  set "DIDBK=1"
)
for %%F in ("%GMOD%\garrysmod\lua\bin\gmcl_zhphone_win64.dll" "%GMOD%\bin\win64\avcodec-zhphone32-62.dll" "%GMOD%\bin\win64\avformat-zhphone32-62.dll" "%GMOD%\bin\win64\avutil-zhphone32-60.dll" "%GMOD%\garrysmod\cfg\zhphone_native.cfg") do (
  if exist %%F (
    mkdir "%BK%\files" 2>nul
    copy /Y %%F "%BK%\files\" >nul
    set "DIDBK=1"
  )
)
if defined DIDBK echo Backup of the old files: "%BK%"

rem ---- 4. copy
echo Copying the addon...
robocopy "%SRC%\garrysmod\addons\zcity_phone" "%GMOD%\garrysmod\addons\zcity_phone" /E /R:2 /W:1 /NFL /NDL /NJH /NJS /NP >nul
if errorlevel 8 (
  echo [ERROR] Copying garrysmod\addons\zcity_phone failed.
  goto :fail
)
echo Copying the native recorder...
if not exist "%GMOD%\garrysmod\lua\bin\" mkdir "%GMOD%\garrysmod\lua\bin"
copy /Y "%SRC%\garrysmod\lua\bin\gmcl_zhphone_win64.dll" "%GMOD%\garrysmod\lua\bin\" >nul || goto :copyfail
if not exist "%GMOD%\bin\win64\" mkdir "%GMOD%\bin\win64"
copy /Y "%SRC%\bin\win64\avcodec-zhphone32-62.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
copy /Y "%SRC%\bin\win64\avformat-zhphone32-62.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
copy /Y "%SRC%\bin\win64\avutil-zhphone32-60.dll" "%GMOD%\bin\win64\" >nul || goto :copyfail
if not exist "%GMOD%\garrysmod\cfg\" mkdir "%GMOD%\garrysmod\cfg"
copy /Y "%SRC%\garrysmod\cfg\zhphone_native.cfg" "%GMOD%\garrysmod\cfg\" >nul || goto :copyfail
rem files from a downloaded zip carry the "downloaded from the internet" mark: remove it
powershell -NoProfile -Command "Get-ChildItem -LiteralPath ($env:GMOD+'\garrysmod\lua\bin'),($env:GMOD+'\bin\win64') -Filter *zhphone* | Unblock-File" >nul 2>nul

rem ---- 5. other copies of the phone addon would be loaded too
for /d %%D in ("%GMOD%\garrysmod\addons\*") do (
  if /i not "%%~nxD"=="zcity_phone" if exist "%%~D\lua\autorun\client\cl_stts_phone_recorder31.lua" echo [WARNING] Another copy of the phone addon: "%%~D" - move it out of addons.
)

echo.
echo Done. Installed:
echo   garrysmod\addons\zcity_phone
echo   garrysmod\lua\bin\gmcl_zhphone_win64.dll
echo   bin\win64\avcodec-zhphone32-62.dll, avformat-zhphone32-62.dll, avutil-zhphone32-60.dll
echo   garrysmod\cfg\zhphone_native.cfg
echo.
echo Start Garry's Mod and type ONCE in the console:  exec zhphone_native
echo After a recording, zhphone_rec_stats shows the recorder and the clip sound state.
echo A dedicated server needs garrysmod\addons\zcity_phone too ^(no DLL on the server^).
echo.
pause
exit /b 0

:running
echo [ERROR] Garry's Mod ^(or another Source game^) is running. Close it completely and run install.bat again.
goto :fail
:copyfail
echo [ERROR] A file could not be copied ^(Garry's Mod still running? No write access - run install.bat as administrator^).
goto :fail
:fail
echo.
pause
exit /b 1

rem ---- helpers
:tryLib
if defined GMOD exit /b 0
if "%~1"=="" exit /b 0
set "LIB=%~1"
set "LIB=%LIB:\\=\%"
if exist "%LIB%\steamapps\common\GarrysMod\garrysmod\" set "GMOD=%LIB%\steamapps\common\GarrysMod"
exit /b 0
:tryGmod
if "%~1"=="" exit /b 0
set "TRY=%~1"
if "%TRY:~-1%"=="\" set "TRY=%TRY:~0,-1%"
if exist "%TRY%\garrysmod\gameinfo.txt" (set "GMOD=%TRY%" & exit /b 0)
if exist "%TRY%\gameinfo.txt" if exist "%TRY%\..\garrysmod\" for %%P in ("%TRY%\..") do set "GMOD=%%~fP"
exit /b 0
