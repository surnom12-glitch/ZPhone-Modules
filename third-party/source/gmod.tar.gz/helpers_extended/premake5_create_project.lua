group("garrysmod_common")
	project("helpers_extended")
		kind("StaticLib")
		location("../projects/" .. os.target() .. "/" .. _ACTION)
		targetdir("%{prj.location}/%{cfg.architecture}/%{cfg.buildcfg}")
		debugdir("%{prj.location}/%{cfg.architecture}/%{cfg.buildcfg}")
		objdir("!%{prj.location}/%{cfg.architecture}/%{cfg.buildcfg}/intermediate/%{prj.name}")
		defines("IS_SERVERSIDE=true")
		includedirs({"../include", "include", "include/GarrysMod"})
		files({
			"../include/Platform.hpp",
			"include/**.h",
			"include/**.hpp",
			"source/*.cpp",
			"source/" .. os.target() .. "/*.cpp",
			"source/" .. os.target() .. "/%{cfg.architecture}/*.cpp"
		})
		vpaths({
			["Header files/*"] = {"../include/**.hpp", "include/**.h", "include/**.hpp"},
			["Source files/*"] = "source/**.cpp"
		})

		filter("system:linux or macosx")
			links("dl")

		IncludeHelpers()
		IncludeScanning()
